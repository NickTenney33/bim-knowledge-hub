import type { KnowledgeEntry } from "./types"

// Mock data for BIM Knowledge Hub
export const mockKnowledgeEntries: KnowledgeEntry[] = [
  {
    id: "1",
    title: "矿棉板与石膏板节点",
    description: "吊顶矿棉板与石膏板相接节点构造做法及施工要点",
    professional: "architecture",
    componentType: "other",
    workProcess: "other",
    riskLevel: "normal",
    tags: ["吊顶", "矿棉板", "石膏板", "节点"],
    textContent: `
      <h1>矿棉板与石膏板节点</h1>
      
      <h2>使用区域</h2>
      <p>适用于办公楼、会议室等公共区域，矿棉板与石膏板吊顶交接部位</p>
      
      <h2>施工要点</h2>
      <ol>
        <li>龙骨系统应确保平整，高差控制在±3mm以内</li>
        <li>矿棉板与石膏板交接处应设置收边龙骨</li>
        <li>石膏板接缝处理应平整，刮腻子前需贴防裂网格布</li>
        <li>矿棉板安装应留缝均匀，一般为1-2mm</li>
      </ol>
      
      <h2>注意事项</h2>
      <ul>
        <li><strong>龙骨间距：</strong>石膏板区域主龙骨间距≤1200mm，次龙骨间距≤400mm</li>
        <li><strong>材料选择：</strong>矿棉板应选用吸声系数高的产品，厚度一般为15-20mm</li>
        <li><strong>防火要求：</strong>两种材料均应满足A级防火要求</li>
        <li><strong>高差处理：</strong>交接处若有高差，应采用铝合金收边条过渡</li>
      </ul>
      
      <h2>典型问题</h2>
      <h3>1. 接缝不平整</h3>
      <p>原因：龙骨系统不平整、安装不规范</p>
      <p>解决：加强龙骨调平、规范施工工艺</p>
      
      <h3>2. 矿棉板易松动</h3>
      <p>原因：龙骨间距过大、固定不牢</p>
      <p>解决：严格控制龙骨间距、增加固定点</p>
    `,
    cadFiles: [
      {
        id: "cad-1",
        name: "矿棉板与石膏板节点详图.dwg",
        url: "/cad-drawing-concrete-slab.jpg",
        type: "cad",
        size: 1536000,
        uploadedAt: new Date("2024-03-01"),
      },
    ],
    images: [
      {
        id: "img-1",
        name: "节点施工现场照片.jpg",
        url: "/concrete-slab-construction-site.jpg",
        type: "image",
        size: 890000,
        uploadedAt: new Date("2024-03-01"),
      },
    ],
    rvtModel: {
      id: "rvt-1",
      name: "房建BIM样板工程__矿棉板与石膏板相接.rvt",
      url: "https://www.cloudbimcdn.com/a/bim/bimShare/t0080a5BgV",
      type: "rvt",
      size: 3584000,
      uploadedAt: new Date("2024-03-01"),
    },
    status: "published",
    accessScope: "company",
    version: 1,
    createdAt: new Date("2024-03-01"),
    updatedAt: new Date("2024-03-01"),
    createdBy: "张工",
    views: 245,
  },
  {
    id: "2",
    title: "楼梯模板支设节点",
    description: "楼梯模板支撑系统构造及施工工艺要点",
    professional: "structure",
    componentType: "other",
    workProcess: "formwork",
    riskLevel: "high-risk",
    tags: ["楼梯", "模板", "支撑", "安全"],
    textContent: `
      <h1>楼梯模板支设节点</h1>
      
      <h2>使用区域</h2>
      <p>适用于现浇钢筋混凝土楼梯施工，包括直跑楼梯、双跑楼梯等类型</p>
      
      <h2>施工要点</h2>
      <ol>
        <li>支撑立杆应垂直设置，底部应设置可调底座</li>
        <li>楼梯底模应采用18mm厚竹胶板或木模板</li>
        <li>踏步模板应固定牢固，确保尺寸准确</li>
        <li>支撑体系应进行承载力验算，确保安全</li>
        <li>模板拼缝应严密，防止漏浆</li>
      </ol>
      
      <h2>注意事项</h2>
      <ul>
        <li><strong>支撑间距：</strong>立杆纵横向间距一般为800-1000mm</li>
        <li><strong>踏步尺寸：</strong>踏面宽度260-300mm，踢面高度150-175mm</li>
        <li><strong>安全防护：</strong>支撑系统应设置扫地杆和水平拉杆</li>
        <li><strong>拆模时间：</strong>混凝土强度达到设计强度的75%后方可拆除</li>
      </ul>
      
      <h2>典型问题</h2>
      <h3>1. 踏步尺寸不准确</h3>
      <p>原因：模板制作不精确、固定不牢</p>
      <p>解决：采用定型模板、加强固定措施</p>
      
      <h3>2. 楼梯底面不平整</h3>
      <p>原因：支撑系统不牢固、模板变形</p>
      <p>解决：加密支撑、选用优质模板材料</p>
      
      <h3>3. 混凝土漏浆</h3>
      <p>原因：模板拼缝不严密</p>
      <p>解决：模板拼缝处贴海绵条或胶带密封</p>
    `,
    cadFiles: [
      {
        id: "cad-2",
        name: "楼梯模板支设详图.dwg",
        url: "/cad-drawing-concrete-slab.jpg",
        type: "cad",
        size: 1792000,
        uploadedAt: new Date("2024-03-05"),
      },
    ],
    images: [
      {
        id: "img-2",
        name: "楼梯模板施工照片.jpg",
        url: "/shear-wall-rebar-detail.jpg",
        type: "image",
        size: 1024000,
        uploadedAt: new Date("2024-03-05"),
      },
    ],
    rvtModel: {
      id: "rvt-2",
      name: "房建BIM样板工程-楼梯模板支设模型NLG.rvt",
      url: "https://www.cloudbimcdn.com/a/bim/bimShare/LrzJvpqa6l",
      type: "rvt",
      size: 4608000,
      uploadedAt: new Date("2024-03-05"),
    },
    status: "published",
    accessScope: "company",
    version: 2,
    createdAt: new Date("2024-03-05"),
    updatedAt: new Date("2024-03-08"),
    createdBy: "李工",
    views: 312,
  },
  {
    id: "3",
    title: "装饰装修墙面作法节点",
    description: "室内装饰墙面构造层次及施工工艺标准",
    professional: "decoration",
    componentType: "wall",
    workProcess: "other",
    riskLevel: "normal",
    tags: ["装饰", "墙面", "抹灰", "涂料"],
    textContent: `
      <h1>装饰装修墙面作法节点</h1>
      
      <h2>使用区域</h2>
      <p>适用于办公楼、住宅等建筑的室内墙面装饰施工</p>
      
      <h2>施工要点</h2>
      <ol>
        <li>基层清理：墙面应清理干净，无油污、浮灰</li>
        <li>找平层施工：采用1:3水泥砂浆找平，厚度5-10mm</li>
        <li>界面处理：刷界面剂增强粘结力</li>
        <li>腻子层施工：批刮耐水腻子2-3遍，打磨平整</li>
        <li>面层施工：涂刷底漆一遍、面漆两遍</li>
      </ol>
      
      <h2>注意事项</h2>
      <ul>
        <li><strong>基层要求：</strong>墙面平整度≤3mm，垂直度≤3mm</li>
        <li><strong>材料选择：</strong>采用环保型材料，符合国家标准</li>
        <li><strong>施工环境：</strong>温度5-35℃，相对湿度≤85%</li>
        <li><strong>质量检查：</strong>涂层应均匀、无流坠、无色差</li>
      </ul>
      
      <h2>典型问题</h2>
      <h3>1. 墙面开裂</h3>
      <p>原因：基层处理不当、腻子层过厚、材料质量差</p>
      <p>解决：加强基层处理、控制腻子厚度、选用优质材料</p>
      
      <h3>2. 涂层剥落</h3>
      <p>原因：基层疏松、界面处理不到位</p>
      <p>解决：清除疏松基层、刷界面剂增强粘结</p>
      
      <h3>3. 色差明显</h3>
      <p>原因：涂料搅拌不均、涂刷不均匀、分批施工</p>
      <p>解决：充分搅拌涂料、采用同一批次材料、均匀涂刷</p>
    `,
    cadFiles: [
      {
        id: "cad-3",
        name: "墙面做法详图.dwg",
        url: "/wall-insulation-detail.jpg",
        type: "cad",
        size: 1280000,
        uploadedAt: new Date("2024-03-10"),
      },
    ],
    images: [
      {
        id: "img-3",
        name: "墙面施工现场.jpg",
        url: "/wall-insulation-construction.jpg",
        type: "image",
        size: 768000,
        uploadedAt: new Date("2024-03-10"),
      },
    ],
    rvtModel: {
      id: "rvt-3",
      name: "房建BIM样板工程_装饰装修墙面作法二.rvt",
      url: "https://www.cloudbimcdn.com/a/bim/bimShare/OKUx4h1cCz",
      type: "rvt",
      size: 2816000,
      uploadedAt: new Date("2024-03-10"),
    },
    status: "published",
    accessScope: "company",
    version: 1,
    createdAt: new Date("2024-03-10"),
    updatedAt: new Date("2024-03-10"),
    createdBy: "王工",
    views: 189,
  },
  {
    id: "4",
    title: "空调风管节点",
    description: "空调风管系统安装节点构造及施工规范",
    professional: "mep",
    componentType: "other",
    workProcess: "installation",
    riskLevel: "important",
    tags: ["空调", "风管", "安装", "机电"],
    textContent: `
      <h1>空调风管节点</h1>
      
      <h2>使用区域</h2>
      <p>适用于办公楼、商业建筑等的空调通风系统风管安装</p>
      
      <h2>施工要点</h2>
      <ol>
        <li>风管制作应平直，咬口连接应牢固密封</li>
        <li>风管吊架间距：镀锌钢板风管≤4m，复合风管≤3m</li>
        <li>风管与支吊架接触处应垫橡胶垫，防止振动噪声</li>
        <li>风管穿墙、穿楼板处应设套管，缝隙填充不燃材料</li>
        <li>风管保温应密实、平整，保温钉固定牢固</li>
      </ol>
      
      <h2>注意事项</h2>
      <ul>
        <li><strong>风管材质：</strong>镀锌钢板风管厚度0.5-1.2mm，根据风管尺寸确定</li>
        <li><strong>法兰连接：</strong>法兰螺栓间距≤150mm，螺母应在同侧</li>
        <li><strong>漏风量：</strong>风管系统漏风量应符合规范要求，中压系统≤2%</li>
        <li><strong>保温厚度：</strong>空调送风管保温厚度一般为25-40mm</li>
        <li><strong>净高控制：</strong>风管底标高应满足室内净高要求</li>
      </ul>
      
      <h2>典型问题</h2>
      <h3>1. 风管漏风</h3>
      <p>原因：咬口不严密、法兰连接不紧密、风管破损</p>
      <p>解决：加强制作质量控制、法兰连接涂密封胶、及时修补破损</p>
      
      <h3>2. 风管振动噪声大</h3>
      <p>原因：支吊架固定不牢、未设减振措施</p>
      <p>解决：加密支吊架、设置橡胶减振垫</p>
      
      <h3>3. 保温层脱落</h3>
      <p>原因：保温钉固定不牢、保温材料质量差</p>
      <p>解决：增加保温钉数量、选用优质保温材料</p>
    `,
    cadFiles: [
      {
        id: "cad-4",
        name: "风管系统详图.dwg",
        url: "/cad-drawing-concrete-slab.jpg",
        type: "cad",
        size: 2048000,
        uploadedAt: new Date("2024-03-15"),
      },
    ],
    images: [
      {
        id: "img-4",
        name: "风管安装现场.jpg",
        url: "/concrete-slab-construction-site.jpg",
        type: "image",
        size: 896000,
        uploadedAt: new Date("2024-03-15"),
      },
    ],
    rvtModel: {
      id: "rvt-4",
      name: "房建BIM样板工程_节点_空调风管.rvt",
      url: "https://www.cloudbimcdn.com/a/bim/bimShare/beO2SPIgS0",
      type: "rvt",
      size: 5120000,
      uploadedAt: new Date("2024-03-15"),
    },
    status: "published",
    accessScope: "company",
    version: 1,
    createdAt: new Date("2024-03-15"),
    updatedAt: new Date("2024-03-15"),
    createdBy: "赵工",
    views: 267,
  },
]

export const professionalLabels: Record<string, string> = {
  architecture: "建筑",
  structure: "结构",
  mep: "机电",
  decoration: "装饰",
  other: "其他",
}

export const componentTypeLabels: Record<string, string> = {
  slab: "楼板",
  wall: "墙体",
  beam: "梁",
  column: "柱",
  node: "节点",
  other: "其他",
}

export const workProcessLabels: Record<string, string> = {
  formwork: "模板",
  rebar: "钢筋",
  concrete: "混凝土",
  installation: "安装",
  other: "其他",
}

export const riskLevelLabels: Record<string, string> = {
  normal: "一般",
  important: "重要",
  "high-risk": "高风险",
}
