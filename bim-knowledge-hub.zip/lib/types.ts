// Knowledge entry types for BIM 3D Knowledge Hub

export type Professional = "architecture" | "structure" | "mep" | "decoration" | "other"
export type ComponentType = "slab" | "wall" | "beam" | "column" | "node" | "other"
export type WorkProcess = "formwork" | "rebar" | "concrete" | "installation" | "other"
export type RiskLevel = "normal" | "important" | "high-risk"
export type ContentStatus = "draft" | "review" | "published"
export type AccessScope = "department" | "project" | "company"

export interface KnowledgeEntry {
  id: string
  title: string
  description: string
  professional: Professional
  componentType: ComponentType
  workProcess: WorkProcess
  riskLevel: RiskLevel
  tags: string[]

  // Content
  textContent: string
  usageArea?: string // 使用区域
  precautions?: string // 注意事项
  typicalIssues?: string // 典型问题与风险提示

  cadFiles: FileAttachment[]
  images: FileAttachment[]
  rvtModel?: FileAttachment

  // Metadata
  status: ContentStatus
  accessScope: AccessScope
  version: number
  versionNotes?: string // 版本更新说明
  createdAt: Date
  updatedAt: Date
  createdBy: string
  views: number
}

export interface FileAttachment {
  id: string
  name: string
  url: string
  type: "cad" | "image" | "rvt" | "gltf"
  size: number
  uploadedAt: Date
}

export interface User {
  id: string
  name: string
  email: string
  role: "viewer" | "editor" | "reviewer" | "admin"
  department: string
  avatar?: string
}

export interface SearchFilters {
  professional?: Professional
  componentType?: ComponentType
  workProcess?: WorkProcess
  riskLevel?: RiskLevel
  tags?: string[]
  query?: string
}
