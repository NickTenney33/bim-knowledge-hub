import { Header } from "@/components/header"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { QrCode, Download, Bookmark, Share2 } from "lucide-react"
import Link from "next/link"
import { mockKnowledgeEntries, professionalLabels } from "@/lib/mock-data"
import { notFound } from "next/navigation"

export default async function QRAccessPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const entry = mockKnowledgeEntries.find((e) => e.id === id)

  if (!entry) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-8 max-w-2xl">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <QrCode className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-2xl font-bold mb-2">扫码快速访问</h1>
          <p className="text-muted-foreground">已为您定位到该知识条目</p>
        </div>

        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="outline">{professionalLabels[entry.professional]}</Badge>
              <Badge variant={entry.riskLevel === "high-risk" ? "destructive" : "secondary"}>
                {entry.riskLevel === "high-risk" ? "高风险" : entry.riskLevel === "important" ? "重要" : "普通"}
              </Badge>
            </div>

            <h2 className="text-xl font-bold mb-3">{entry.title}</h2>
            <p className="text-muted-foreground mb-6 leading-relaxed">{entry.description}</p>

            <div className="space-y-2">
              <Button className="w-full" size="lg" asChild>
                <Link href={`/knowledge/${entry.id}`}>查看完整内容</Link>
              </Button>
              <div className="grid grid-cols-3 gap-2">
                <Button variant="outline" size="sm">
                  <Bookmark className="h-4 w-4 mr-1" />
                  收藏
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-1" />
                  下载
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4 mr-1" />
                  分享
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-500/50 bg-blue-500/5">
          <CardContent className="p-4">
            <div className="flex gap-3">
              <QrCode className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold text-blue-900 dark:text-blue-100 mb-1">移动端优化</p>
                <p className="text-blue-800 dark:text-blue-200">
                  本页面已针对移动设备优化，支持离线查看。建议收藏或下载离线包以便现场使用。
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
