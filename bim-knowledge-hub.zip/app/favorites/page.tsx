import { Header } from "@/components/header"
import { MobileNav } from "@/components/mobile-nav"
import { Button } from "@/components/ui/button"
import { Bookmark } from "lucide-react"

export default function FavoritesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-8 pb-24 md:pb-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">我的收藏</h1>
          <p className="text-muted-foreground">快速访问您收藏的知识条目</p>
        </div>

        <div className="flex flex-col items-center justify-center py-12">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted mb-4">
            <Bookmark className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">暂无收藏</h3>
          <p className="text-sm text-muted-foreground mb-6">浏览知识库并收藏您感兴趣的内容</p>
          <Button asChild>
            <a href="/knowledge">浏览知识库</a>
          </Button>
        </div>
      </main>

      <MobileNav />
    </div>
  )
}
