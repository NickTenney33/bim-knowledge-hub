import { Header } from "@/components/header"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, Building2, Shield, BarChart3 } from "lucide-react"
import { OrganizationManagement } from "@/components/admin/organization-management"
import { UserManagement } from "@/components/admin/user-management"
import { PermissionManagement } from "@/components/admin/permission-management"
import { AnalyticsDashboard } from "@/components/admin/analytics-dashboard"

export default function AdminPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container px-4 md:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">系统管理</h1>
          <p className="text-muted-foreground">管理组织架构、用户权限和系统设置</p>
        </div>

        <div className="grid md:grid-cols-4 gap-4 md:gap-6 mb-8">
          <Card>
            <CardContent className="p-5 md:p-6">
              <div className="flex items-center justify-between mb-2">
                <Users className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold">128</div>
              <p className="text-sm text-muted-foreground">用户总数</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5 md:p-6">
              <div className="flex items-center justify-between mb-2">
                <Building2 className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold">12</div>
              <p className="text-sm text-muted-foreground">部门数量</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5 md:p-6">
              <div className="flex items-center justify-between mb-2">
                <Shield className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold">4</div>
              <p className="text-sm text-muted-foreground">角色类型</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5 md:p-6">
              <div className="flex items-center justify-between mb-2">
                <BarChart3 className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold">1.2K</div>
              <p className="text-sm text-muted-foreground">日活跃</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="users" className="w-full">
          <TabsList className="grid w-full max-w-2xl grid-cols-4">
            <TabsTrigger value="users">
              <Users className="h-4 w-4 mr-2" />
              用户管理
            </TabsTrigger>
            <TabsTrigger value="organization">
              <Building2 className="h-4 w-4 mr-2" />
              组织架构
            </TabsTrigger>
            <TabsTrigger value="permissions">
              <Shield className="h-4 w-4 mr-2" />
              权限管理
            </TabsTrigger>
            <TabsTrigger value="analytics">
              <BarChart3 className="h-4 w-4 mr-2" />
              数据统计
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="mt-6">
            <UserManagement />
          </TabsContent>

          <TabsContent value="organization" className="mt-6">
            <OrganizationManagement />
          </TabsContent>

          <TabsContent value="permissions" className="mt-6">
            <PermissionManagement />
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <AnalyticsDashboard />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
