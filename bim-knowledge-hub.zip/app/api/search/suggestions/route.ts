import { type NextRequest, NextResponse } from "next/server"
import { EvolinkService } from "@/services/evolink"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get("q")

    if (!query || query.trim().length < 2) {
      return NextResponse.json({ suggestions: [] })
    }

    const apiKey = process.env.EVOLINK_API_KEY
    const evolink = new EvolinkService(apiKey)

    const suggestions = await evolink.getSuggestions(query.trim())

    return NextResponse.json({ suggestions })
  } catch (error) {
    console.error("[v0] Search suggestions error:", error)
    return NextResponse.json({ suggestions: [] })
  }
}
