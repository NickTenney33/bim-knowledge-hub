import { type NextRequest, NextResponse } from "next/server"
import { EvolinkService } from "@/services/evolink"

export async function POST(request: NextRequest) {
  try {
    const { query, context } = await request.json()

    if (!query || typeof query !== "string") {
      return NextResponse.json({ error: "Invalid query parameter" }, { status: 400 })
    }

    const apiKey = process.env.EVOLINK_API_KEY
    if (!apiKey) {
      return NextResponse.json(
        {
          error: "EVOLINK_API_KEY not configured",
          message: "请在环境变量中设置 EVOLINK_API_KEY",
        },
        { status: 503 },
      )
    }

    const evolink = new EvolinkService(apiKey)
    const results = await evolink.fetchAI(query, context)

    return NextResponse.json(results)
  } catch (error) {
    console.error("[v0] AI search error:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "Search failed",
        message: "搜索服务暂时不可用，请稍后重试",
      },
      { status: 500 },
    )
  }
}
