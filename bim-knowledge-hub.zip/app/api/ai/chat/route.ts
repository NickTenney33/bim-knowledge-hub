import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { messages } = await request.json()

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: "无效的请求格式" }, { status: 400 })
    }

    const apiKey = process.env.EVOLINK_API_KEY
    if (!apiKey) {
      console.error("[v0] EVOLINK_API_KEY not configured")
      return NextResponse.json(
        {
          error: "AI功能未配置",
          message: "请在环境变量中设置 EVOLINK_API_KEY 以启用AI功能。",
          fallback: true,
        },
        { status: 503 },
      )
    }

    const response = await fetch("https://api.evolink.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: `你是一个专业的建筑工程知识助手，专门帮助工程人员解答关于BIM、构造做法、施工工艺、质量管控等方面的问题。

你的职责是：
1. 解答工程技术问题，提供专业、准确的建议
2. 引用相关的规范标准和最佳实践
3. 解释施工要点和质量管控标准
4. 推荐相关的知识库条目

回答时请：
- 使用简洁明了的语言
- 提供具体的数据和标准
- 分点列出重要信息
- 必要时给出施工建议和注意事项`,
          },
          ...messages,
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      console.error("[v0] EvoLink API error:", {
        status: response.status,
        statusText: response.statusText,
        error: errorData,
      })

      if (response.status === 401) {
        return NextResponse.json(
          {
            error: "API密钥无效",
            message: "EVOLINK_API_KEY 无效或已过期，请检查环境变量配置。",
            fallback: true,
          },
          { status: 401 },
        )
      }

      throw new Error("AI服务暂时不可用")
    }

    const data = await response.json()
    const aiMessage = data.choices[0]?.message?.content || "抱歉，我无法生成回答。"

    return NextResponse.json({
      message: aiMessage,
      model: data.model,
      usage: data.usage,
    })
  } catch (error) {
    console.error("[v0] AI Chat error:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "处理请求时发生错误",
        fallback: true,
      },
      { status: 500 },
    )
  }
}
