import { Header } from "@/components/header"
import { MobileNav } from "@/components/mobile-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Building2, Layers, FileText, Eye, ChevronRight, Sparkles } from "lucide-react"
import Link from "next/link"
import { mockKnowledgeEntries, professionalLabels, riskLevelLabels } from "@/lib/mock-data"
import { HomeAISearch } from "@/components/home-ai-search"

export default function HomePage() {
  const topEntries = [...mockKnowledgeEntries].sort((a, b) => b.views - a.views).slice(0, 3)
  const recentEntries = [...mockKnowledgeEntries]
    .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())
    .slice(0, 4)

  return (
    <div className="min-h-screen">
      <Header />

      <main className="container px-4 md:px-6 lg:px-8 py-6 md:py-10 pb-24 md:pb-10">
        <section className="mb-10 md:mb-12 rounded-xl bg-gradient-to-br from-primary/15 via-accent/10 to-info/5 p-6 md:p-10 lg:p-12 mx-auto max-w-7xl border-2 glow-border fade-in relative overflow-hidden">
          {/* 背景光晕效果 */}
          <div className="absolute top-0 right-0 w-72 h-72 bg-gradient-to-br from-accent/30 to-transparent rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-primary/30 to-transparent rounded-full blur-3xl animate-pulse delay-500" />

          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-[500px] h-[400px] opacity-10 dark:opacity-20">
            <svg viewBox="0 0 500 400" className="w-full h-full">
              {/* 建筑平面图线框 */}
              <rect x="50" y="50" width="200" height="150" fill="none" stroke="currentColor" strokeWidth="2" />
              <rect x="70" y="70" width="50" height="60" fill="none" stroke="currentColor" strokeWidth="1.5" />
              <rect x="140" y="70" width="50" height="60" fill="none" stroke="currentColor" strokeWidth="1.5" />
              <line x1="50" y1="125" x2="250" y2="125" stroke="currentColor" strokeWidth="1" strokeDasharray="5,5" />

              {/* 工程节点图 - 梁柱节点结构 */}
              {/* 主柱 */}
              <rect x="340" y="80" width="30" height="200" fill="none" stroke="currentColor" strokeWidth="2.5" />
              {/* 梁 */}
              <rect x="300" y="140" width="110" height="25" fill="none" stroke="currentColor" strokeWidth="2.5" />
              <rect x="300" y="180" width="110" height="25" fill="none" stroke="currentColor" strokeWidth="2.5" />

              {/* 钢筋连接线 */}
              <line x1="310" y1="152" x2="330" y2="152" stroke="currentColor" strokeWidth="1.5" />
              <line x1="380" y1="152" x2="400" y2="152" stroke="currentColor" strokeWidth="1.5" />
              <line x1="310" y1="192" x2="330" y2="192" stroke="currentColor" strokeWidth="1.5" />
              <line x1="380" y1="192" x2="400" y2="192" stroke="currentColor" strokeWidth="1.5" />

              {/* 箍筋 */}
              <line x1="345" y1="100" x2="365" y2="100" stroke="currentColor" strokeWidth="1" strokeDasharray="3,3" />
              <line x1="345" y1="120" x2="365" y2="120" stroke="currentColor" strokeWidth="1" strokeDasharray="3,3" />
              <line x1="345" y1="220" x2="365" y2="220" stroke="currentColor" strokeWidth="1" strokeDasharray="3,3" />
              <line x1="345" y1="240" x2="365" y2="240" stroke="currentColor" strokeWidth="1" strokeDasharray="3,3" />

              {/* 节点标注圆圈 */}
              <circle
                cx="340"
                cy="140"
                r="6"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="animate-pulse"
              />
              <circle
                cx="370"
                cy="140"
                r="6"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="animate-pulse delay-100"
              />
              <circle
                cx="340"
                cy="180"
                r="6"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="animate-pulse delay-200"
              />
              <circle
                cx="370"
                cy="180"
                r="6"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="animate-pulse delay-300"
              />
              <circle
                cx="340"
                cy="205"
                r="6"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="animate-pulse delay-400"
              />
              <circle
                cx="370"
                cy="205"
                r="6"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="animate-pulse delay-500"
              />

              {/* 尺寸标注线 */}
              <line x1="420" y1="140" x2="450" y2="140" stroke="currentColor" strokeWidth="1" />
              <line x1="420" y1="205" x2="450" y2="205" stroke="currentColor" strokeWidth="1" />
              <line x1="445" y1="140" x2="445" y2="205" stroke="currentColor" strokeWidth="1" strokeDasharray="4,4" />

              {/* 节点核心区域高亮 */}
              <rect
                x="332"
                y="132"
                width="46"
                height="80"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeDasharray="6,4"
                opacity="0.6"
              />
            </svg>
          </div>

          {/* 装饰性网格 - 左下角 */}
          <div className="absolute left-0 bottom-0 w-[300px] h-[200px] opacity-10 dark:opacity-15">
            <svg viewBox="0 0 300 200" className="w-full h-full">
              <defs>
                <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
                  <path d="M 30 0 L 0 0 0 30" fill="none" stroke="currentColor" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="300" height="200" fill="url(#grid)" />
              <circle cx="50" cy="150" r="3" fill="currentColor" className="animate-pulse" />
              <circle cx="100" cy="120" r="3" fill="currentColor" className="animate-pulse delay-150" />
              <circle cx="150" cy="160" r="3" fill="currentColor" className="animate-pulse delay-300" />
            </svg>
          </div>

          <div className="max-w-3xl relative z-10">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight mb-3 md:mb-4 text-balance gradient-text-animated animate-in slide-in-from-left duration-700">
              BIM 三维知识库
            </h1>
            <p className="text-base md:text-lg lg:text-xl text-muted-foreground mb-5 md:mb-6 text-pretty leading-relaxed animate-in slide-in-from-left duration-700 delay-100">
              随时随地查看标准化的构造做法、管控要点和BIM模型,为工程施工提供统一知识入口
            </p>
            <div className="flex flex-col sm:flex-row gap-3 animate-in slide-in-from-left duration-700 delay-200">
              <Button size="lg" asChild className="gradient-button">
                <Link href="/knowledge">
                  <Building2 className="mr-2 h-5 w-5" />
                  浏览知识库
                </Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="mb-10 md:mb-12 max-w-7xl mx-auto">
          <HomeAISearch />
        </section>

        <section className="mb-10 md:mb-12 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-5 md:mb-6">
            <h2 className="text-xl md:text-2xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
              热门内容
            </h2>
            <Button variant="ghost" asChild className="hover:glow-border">
              <Link href="/knowledge">
                查看全部
                <ChevronRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-5 md:gap-6">
            {topEntries.map((entry, index) => (
              <Card
                key={entry.id}
                className="glass-card glow-hover slide-in group"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardHeader className="space-y-2.5 p-4">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className="border-primary/50 text-xs font-medium px-2 py-0.5">
                      {professionalLabels[entry.professional]}
                    </Badge>
                    <Badge
                      variant={
                        entry.riskLevel === "high-risk"
                          ? "destructive"
                          : entry.riskLevel === "important"
                            ? "default"
                            : "secondary"
                      }
                      className="text-xs font-medium px-2 py-0.5 shadow-sm"
                    >
                      {riskLevelLabels[entry.riskLevel]}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg font-bold leading-snug line-clamp-2 text-balance group-hover:text-primary transition-colors duration-300">
                    {entry.title}
                  </CardTitle>
                  <CardDescription className="text-sm leading-relaxed line-clamp-2 text-pretty">
                    {entry.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-4 pb-4">
                  <div className="flex items-center justify-between pt-3 border-t border-border/40">
                    <div className="flex items-center gap-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1.5">
                        <Eye className="h-4 w-4 opacity-70" />
                        <span className="font-medium">{entry.views}</span>
                      </div>
                      {entry.rvtModel && (
                        <div className="flex items-center gap-1.5 text-accent">
                          <Layers className="h-4 w-4" />
                          <span className="font-medium">3D</span>
                        </div>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      asChild
                      className="text-primary hover:text-primary/90 hover:bg-primary/10 -mr-2 font-medium h-8"
                    >
                      <Link href={`/knowledge/${entry.id}`} className="flex items-center gap-0.5">
                        查看详情
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-10 md:mb-12 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-5 md:mb-6">
            <h2 className="text-xl md:text-2xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
              最新更新
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
            {recentEntries.map((entry, index) => (
              <Card
                key={entry.id}
                className="glass-card glow-hover slide-in group flex flex-col"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardHeader className="space-y-3 p-5 flex-1">
                  <Badge variant="outline" className="w-fit border-accent/50 text-xs font-medium px-2 py-0.5">
                    {professionalLabels[entry.professional]}
                  </Badge>
                  <CardTitle className="text-base font-bold leading-snug line-clamp-2 text-balance group-hover:text-primary transition-colors duration-300">
                    {entry.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0 mt-auto space-y-2.5">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2.5 border-t border-border/40">
                    <span className="font-medium">{entry.createdBy}</span>
                    <span className="text-border">·</span>
                    <span>{entry.updatedAt.toLocaleDateString("zh-CN")}</span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    asChild
                    className="w-full border-primary/30 hover:border-primary/50 hover:bg-primary/5 hover:text-primary font-medium transition-all duration-300 bg-transparent h-8"
                  >
                    <Link href={`/knowledge/${entry.id}`}>查看详情</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="max-w-7xl mx-auto">
          <h2 className="text-xl md:text-2xl font-bold mb-5 md:mb-6 gradient-text-animated">核心功能</h2>

          <div className="grid md:grid-cols-3 gap-4 md:gap-6">
            <Card className="border-2 glass-card glow-hover floating-animation border-primary/40 group">
              <CardHeader className="space-y-3 p-5">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent shadow-[0_0_30px_rgba(99,102,246,0.5)] icon-glow-primary group-hover:scale-110 transition-transform duration-300">
                  <Layers className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                  3D模型查看
                </CardTitle>
                <CardDescription className="text-sm leading-relaxed">
                  支持Revit原生模型转换与轻量化展示，构件级别交互查看
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 glass-card glow-hover floating-animation delay-100 border-accent/40 group">
              <CardHeader className="space-y-3 p-5">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-accent to-info shadow-[0_0_30px_rgba(139,92,246,0.5)] icon-glow-accent group-hover:scale-110 transition-transform duration-300">
                  <FileText className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-accent to-info">
                  CAD图纸预览
                </CardTitle>
                <CardDescription className="text-sm leading-relaxed">
                  在线查看CAD图纸，支持缩放、测量、图层控制等功能
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 glass-card glow-hover floating-animation delay-200 border-info/40 group">
              <CardHeader className="space-y-3 p-5">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-info to-primary shadow-[0_0_30px_rgba(59,130,246,0.5)] icon-glow-accent group-hover:scale-110 transition-transform duration-300">
                  <Sparkles className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-info to-primary">
                  AI智能助手
                </CardTitle>
                <CardDescription className="text-sm leading-relaxed">
                  自然语言提问，快速获取构造做法和施工要点
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </section>
      </main>

      <MobileNav />
    </div>
  )
}
