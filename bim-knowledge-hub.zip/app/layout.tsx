import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { ThemeProvider } from "@/components/theme-provider"
import { UserRoleProvider } from "@/contexts/user-role-context"
import { StarfieldBackground } from "@/components/starfield-background"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "BIM 三维知识库 | BIM 3D Knowledge Hub",
  description: "工程人员随时随地查看标准化的构造做法、管控要点和BIM模型",
  generator: "v0.app",
  icons: {
    icon: [
      {
        url: "/icon-light-32x32.png",
        media: "(prefers-color-scheme: light)",
      },
      {
        url: "/icon-dark-32x32.png",
        media: "(prefers-color-scheme: dark)",
      },
      {
        url: "/icon.svg",
        type: "image/svg+xml",
      },
    ],
    apple: "/apple-icon.png",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <body className={`font-sans antialiased smooth-scroll`}>
        <ThemeProvider defaultTheme="system">
          <UserRoleProvider>
            <StarfieldBackground />
            <div className="relative z-10">{children}</div>
          </UserRoleProvider>
        </ThemeProvider>
        <Analytics />
      </body>
    </html>
  )
}
