"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { MobileNav } from "@/components/mobile-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { SearchBar } from "@/components/search-bar"
import { AISearchDrawer } from "@/components/ai-search-drawer"
import { Search, Filter, X, Eye, Layers } from "lucide-react"
import { mockKnowledgeEntries, professionalLabels, riskLevelLabels } from "@/lib/mock-data"
import Link from "next/link"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { useSearchParams } from "next/navigation"
import { Suspense } from "react"

function SearchContent() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get("q") || ""

  const [searchQuery, setSearchQuery] = useState(initialQuery)
  const [showResults, setShowResults] = useState(!!initialQuery)
  const [aiDrawerOpen, setAiDrawerOpen] = useState(false)
  const [selectedFilters, setSelectedFilters] = useState<{
    professional: string[]
    riskLevel: string[]
  }>({
    professional: [],
    riskLevel: [],
  })

  useEffect(() => {
    if (initialQuery) {
      setSearchQuery(initialQuery)
      setShowResults(true)
    }
  }, [initialQuery])

  const filteredResults = mockKnowledgeEntries.filter((entry) => {
    const matchesQuery =
      searchQuery === "" ||
      entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesProfessional =
      selectedFilters.professional.length === 0 || selectedFilters.professional.includes(entry.professional)

    const matchesRisk = selectedFilters.riskLevel.length === 0 || selectedFilters.riskLevel.includes(entry.riskLevel)

    return matchesQuery && matchesProfessional && matchesRisk
  })

  const handleSearch = (query?: string) => {
    if (query) setSearchQuery(query)
    setShowResults(true)
  }

  const clearFilters = () => {
    setSelectedFilters({
      professional: [],
      riskLevel: [],
    })
  }

  const activeFilterCount = selectedFilters.professional.length + selectedFilters.riskLevel.length

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container px-4 md:px-6 lg:px-8 py-6 md:py-10 pb-24 md:pb-10">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-6 md:mb-8">
            <h1 className="text-2xl md:text-3xl font-bold mb-2">智能搜索</h1>
            <p className="text-muted-foreground text-pretty">搜索构造做法、构件信息，或使用AI助手自然语言提问</p>
          </div>

          <div className="space-y-3 md:space-y-4 mb-6 md:mb-8">
            <div className="flex gap-2">
              <div className="flex-1">
                <SearchBar
                  placeholder="搜索知识库..."
                  onAIClick={() => setAiDrawerOpen(true)}
                  showAIButton={false}
                  className="w-full"
                />
              </div>
              <Button size="lg" className="px-6" onClick={() => handleSearch(searchQuery)}>
                搜索
              </Button>
              <Sheet>
                <SheetTrigger asChild>
                  <Button size="lg" variant="outline" className="relative bg-transparent">
                    <Filter className="h-5 w-5" />
                    {activeFilterCount > 0 && (
                      <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center">
                        {activeFilterCount}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent>
                  <SheetHeader>
                    <SheetTitle>筛选条件</SheetTitle>
                    <SheetDescription>按专业、风险等级等条件筛选搜索结果</SheetDescription>
                  </SheetHeader>
                  <div className="mt-6 space-y-6">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-semibold">专业</Label>
                        {selectedFilters.professional.length > 0 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedFilters((prev) => ({ ...prev, professional: [] }))}
                          >
                            <X className="h-3 w-3 mr-1" />
                            清除
                          </Button>
                        )}
                      </div>
                      <div className="space-y-2">
                        {Object.entries(professionalLabels).map(([key, label]) => (
                          <div key={key} className="flex items-center space-x-2">
                            <Checkbox
                              id={`filter-prof-${key}`}
                              checked={selectedFilters.professional.includes(key)}
                              onCheckedChange={(checked) => {
                                setSelectedFilters((prev) => ({
                                  ...prev,
                                  professional: checked
                                    ? [...prev.professional, key]
                                    : prev.professional.filter((p) => p !== key),
                                }))
                              }}
                            />
                            <label htmlFor={`filter-prof-${key}`} className="text-sm leading-none cursor-pointer">
                              {label}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-semibold">风险等级</Label>
                        {selectedFilters.riskLevel.length > 0 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedFilters((prev) => ({ ...prev, riskLevel: [] }))}
                          >
                            <X className="h-3 w-3 mr-1" />
                            清除
                          </Button>
                        )}
                      </div>
                      <div className="space-y-2">
                        {Object.entries(riskLevelLabels).map(([key, label]) => (
                          <div key={key} className="flex items-center space-x-2">
                            <Checkbox
                              id={`filter-risk-${key}`}
                              checked={selectedFilters.riskLevel.includes(key)}
                              onCheckedChange={(checked) => {
                                setSelectedFilters((prev) => ({
                                  ...prev,
                                  riskLevel: checked
                                    ? [...prev.riskLevel, key]
                                    : prev.riskLevel.filter((r) => r !== key),
                                }))
                              }}
                            />
                            <label htmlFor={`filter-risk-${key}`} className="text-sm leading-none cursor-pointer">
                              {label}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {activeFilterCount > 0 && (
                      <Button variant="outline" className="w-full bg-transparent" onClick={clearFilters}>
                        清除所有筛选
                      </Button>
                    )}
                  </div>
                </SheetContent>
              </Sheet>
            </div>

            <Button
              variant="outline"
              className="w-full bg-transparent gap-2"
              size="lg"
              onClick={() => setAiDrawerOpen(true)}
            >
              <Search className="h-5 w-5" />
              使用AI智能助手
            </Button>
          </div>

          {showResults && (
            <div className="space-y-4 md:space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="text-lg md:text-xl font-semibold">搜索结果 ({filteredResults.length})</h2>
                {(searchQuery || activeFilterCount > 0) && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSearchQuery("")
                      clearFilters()
                      setShowResults(false)
                    }}
                  >
                    <X className="h-4 w-4 mr-1" />
                    清除搜索
                  </Button>
                )}
              </div>

              {activeFilterCount > 0 && (
                <div className="flex flex-wrap gap-2">
                  {selectedFilters.professional.map((prof) => (
                    <Badge key={prof} variant="secondary">
                      {professionalLabels[prof]}
                      <button
                        className="ml-1"
                        onClick={() => {
                          setSelectedFilters((prev) => ({
                            ...prev,
                            professional: prev.professional.filter((p) => p !== prof),
                          }))
                        }}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                  {selectedFilters.riskLevel.map((risk) => (
                    <Badge key={risk} variant="secondary">
                      {riskLevelLabels[risk]}
                      <button
                        className="ml-1"
                        onClick={() => {
                          setSelectedFilters((prev) => ({
                            ...prev,
                            riskLevel: prev.riskLevel.filter((r) => r !== risk),
                          }))
                        }}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}

              {filteredResults.length === 0 ? (
                <Card className="p-8 md:p-12 text-center">
                  <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg md:text-xl font-semibold mb-2">未找到相关内容</h3>
                  <p className="text-muted-foreground mb-4">尝试使用不同的关键词或调整筛选条件</p>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchQuery("")
                      clearFilters()
                    }}
                  >
                    重置搜索
                  </Button>
                </Card>
              ) : (
                <div className="space-y-3 md:space-y-4">
                  {filteredResults.map((entry) => (
                    <Card key={entry.id} className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex gap-2">
                            <Badge variant="outline">{professionalLabels[entry.professional]}</Badge>
                            {entry.rvtModel && (
                              <Badge variant="secondary">
                                <Layers className="h-3 w-3 mr-1" />
                                3D
                              </Badge>
                            )}
                          </div>
                          <Badge
                            variant={
                              entry.riskLevel === "high-risk"
                                ? "destructive"
                                : entry.riskLevel === "important"
                                  ? "default"
                                  : "secondary"
                            }
                          >
                            {riskLevelLabels[entry.riskLevel]}
                          </Badge>
                        </div>
                        <CardTitle className="text-xl line-clamp-2 text-balance">{entry.title}</CardTitle>
                        <CardDescription className="line-clamp-2 text-pretty">{entry.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="flex flex-wrap gap-2 mb-4">
                          {entry.tags.slice(0, 5).map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Eye className="h-4 w-4" />
                              <span>{entry.views}</span>
                            </div>
                            <span>{entry.createdBy}</span>
                          </div>
                          <Button asChild>
                            <Link href={`/knowledge/${entry.id}`}>查看详情</Link>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}

          {!showResults && (
            <div className="space-y-6 md:space-y-8">
              <div>
                <h2 className="text-sm font-semibold text-muted-foreground mb-3">热门搜索</h2>
                <div className="flex flex-wrap gap-2">
                  {["混凝土楼板", "剪力墙钢筋", "机电管线", "外墙保温", "防水做法"].map((keyword) => (
                    <Button
                      key={keyword}
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        setSearchQuery(keyword)
                        setShowResults(true)
                      }}
                    >
                      {keyword}
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="text-sm font-semibold text-muted-foreground mb-3">常见问题</h2>
                <div className="space-y-2">
                  {[
                    "这类节点怎么施工？",
                    "混凝土楼板厚度偏差标准是多少？",
                    "剪力墙钢筋绑扎有哪些要点？",
                    "机电管线综合排布原则是什么？",
                  ].map((question, index) => (
                    <Card
                      key={index}
                      className="hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => setAiDrawerOpen(true)}
                    >
                      <CardContent className="p-4 flex items-center justify-between">
                        <p className="text-sm">{question}</p>
                        <Search className="h-4 w-4 text-muted-foreground flex-shrink-0 ml-2" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      <MobileNav />
      <AISearchDrawer open={aiDrawerOpen} onOpenChange={setAiDrawerOpen} />
    </div>
  )
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <SearchContent />
    </Suspense>
  )
}
