"use client"

import type React from "react"
import { useState } from "react"
import { Header } from "@/components/header"
import { MobileNav } from "@/components/mobile-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Search, Sparkles, Loader2, AlertCircle, Layers, Eye, Filter } from "lucide-react"
import { mockKnowledgeEntries, professionalLabels, riskLevelLabels } from "@/lib/mock-data"
import Link from "next/link"

function KnowledgeResultCard({ entry }: { entry: (typeof mockKnowledgeEntries)[0] }) {
  return (
    <Link href={`/knowledge/${entry.id}`}>
      <Card className="glass-card glow-hover group">
        <CardHeader className="space-y-2.5 p-4">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="border-primary/50 text-xs font-medium px-2 py-0.5">
              {professionalLabels[entry.professional]}
            </Badge>
            <Badge
              variant={
                entry.riskLevel === "high-risk"
                  ? "destructive"
                  : entry.riskLevel === "important"
                    ? "default"
                    : "secondary"
              }
              className="text-xs font-medium px-2 py-0.5 shadow-sm"
            >
              {riskLevelLabels[entry.riskLevel]}
            </Badge>
          </div>
          <CardTitle className="text-lg font-bold leading-snug line-clamp-2 text-balance group-hover:text-primary transition-colors duration-300">
            {entry.title}
          </CardTitle>
          <CardDescription className="text-sm leading-relaxed line-clamp-2 text-pretty">
            {entry.description}
          </CardDescription>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="flex items-center justify-between pt-3 border-t border-border/40">
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Eye className="h-4 w-4 opacity-70" />
                <span className="font-medium">{entry.views}</span>
              </div>
              {entry.rvtModel && (
                <div className="flex items-center gap-1.5 text-accent">
                  <Layers className="h-4 w-4" />
                  <span className="font-medium">3D</span>
                </div>
              )}
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="text-primary hover:text-primary/90 hover:bg-primary/10 -mr-2 font-medium h-8"
            >
              查看详情
            </Button>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

export default function AISearchPage() {
  const { toast } = useToast()
  const [query, setQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [searchResults, setSearchResults] = useState<(typeof mockKnowledgeEntries)[0][]>([])
  const [hasSearched, setHasSearched] = useState(false)

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim() || isLoading) return

    setIsLoading(true)
    setHasSearched(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 800))

      const results = mockKnowledgeEntries.filter(
        (entry) =>
          entry.title.toLowerCase().includes(query.toLowerCase()) ||
          entry.description.toLowerCase().includes(query.toLowerCase()) ||
          entry.tags.some((tag) => tag.toLowerCase().includes(query.toLowerCase())),
      )

      setSearchResults(results.length > 0 ? results : mockKnowledgeEntries.slice(0, 6))

      if (results.length === 0) {
        toast({
          title: "未找到完全匹配的结果",
          description: "已为您显示相关推荐内容",
        })
      }
    } catch (error) {
      console.error("[v0] Search error:", error)
      toast({
        title: "搜索失败",
        description: "请稍后重试",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const quickSearches = ["混凝土楼板", "钢筋绑扎", "外墙保温", "防水做法", "机电管线"]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container px-4 md:px-6 lg:px-8 py-6 md:py-8">
        <div className="grid lg:grid-cols-[440px,1fr] gap-6 lg:gap-10 max-w-[1600px] mx-auto">
          <div className="lg:sticky lg:top-24 lg:self-start space-y-6">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold">AI智能搜索</h1>
                  <p className="text-sm text-muted-foreground">构造做法 · 施工工艺 · BIM模型</p>
                </div>
              </div>
            </div>

            {!process.env.NEXT_PUBLIC_AI_ENABLED && (
              <Card className="border-amber-500/50 bg-amber-500/5">
                <CardContent className="p-4 flex gap-3">
                  <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-semibold text-amber-900 dark:text-amber-100 mb-1">演示模式</p>
                    <p className="text-amber-800 dark:text-amber-200 text-xs leading-relaxed">
                      配置 EVOLINK_API_KEY 启用完整AI功能
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardContent className="p-5">
                <form onSubmit={handleSearch} className="space-y-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input
                      type="text"
                      placeholder="搜索构造做法、构件..."
                      className="pl-10 h-12 text-base"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      disabled={isLoading}
                    />
                  </div>
                  <Button type="submit" className="w-full h-11" disabled={!query.trim() || isLoading}>
                    {isLoading ? (
                      <>
                        <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                        搜索中...
                      </>
                    ) : (
                      <>
                        <Search className="h-5 w-5 mr-2" />
                        AI智能搜索
                      </>
                    )}
                  </Button>
                  <p className="text-xs text-muted-foreground text-center">使用AI技术精准匹配知识库内容</p>
                </form>
              </CardContent>
            </Card>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-muted-foreground">热门搜索</p>
                <Filter className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="flex flex-wrap gap-2">
                {quickSearches.map((search) => (
                  <Button
                    key={search}
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs bg-transparent"
                    onClick={() => {
                      setQuery(search)
                      handleSearch(new Event("submit") as any)
                    }}
                  >
                    {search}
                  </Button>
                ))}
              </div>
            </div>

            <Card className="bg-muted/30">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-primary" />
                  搜索提示
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-muted-foreground">
                <p>• 输入专业、构造部位或工序关键词</p>
                <p>• 搜索结果按相关度和风险等级排序</p>
                <p>• 点击卡片查看完整的3D模型和图纸</p>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-5">
            {!hasSearched ? (
              <Card className="border-2 border-dashed min-h-[400px] flex items-center justify-center">
                <CardContent className="p-8 text-center max-w-md">
                  <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 mx-auto mb-4">
                    <Search className="h-10 w-10 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">开始搜索</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    输入关键词搜索构造做法、施工节点和BIM模型
                    <br />
                    AI将为您精准匹配相关知识库内容
                  </p>
                </CardContent>
              </Card>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-bold">搜索结果</h2>
                    <p className="text-sm text-muted-foreground mt-1">
                      找到 <span className="font-semibold text-foreground">{searchResults.length}</span> 条相关结果
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    <Filter className="h-4 w-4 mr-2" />
                    筛选
                  </Button>
                </div>

                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                  {searchResults.map((entry, index) => (
                    <div key={entry.id} className="animate-fadeIn" style={{ animationDelay: `${index * 50}ms` }}>
                      <KnowledgeResultCard entry={entry} />
                    </div>
                  ))}
                </div>

                {searchResults.length === 0 && (
                  <Card className="border-2 border-dashed">
                    <CardContent className="p-8 text-center">
                      <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">未找到匹配结果</h3>
                      <p className="text-sm text-muted-foreground">请尝试其他关键词或使用热门搜索</p>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </div>
        </div>
      </main>

      <MobileNav />
      <Toaster />
    </div>
  )
}
