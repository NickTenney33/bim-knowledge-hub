import { Header } from "@/components/header"
import { MobileNav } from "@/components/mobile-nav"
import { KnowledgeGrid } from "@/components/knowledge-grid"
import { KnowledgeFilters } from "@/components/knowledge-filters"
import { Card, CardContent } from "@/components/ui/card"
import { FileText, Layers, Eye, FileImage, ImageIcon } from "lucide-react"
import { mockKnowledgeEntries } from "@/lib/mock-data"

export default function KnowledgePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container px-4 md:px-6 lg:px-8 py-6 md:py-10 pb-24 md:pb-10">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-3xl font-bold mb-2">知识库</h1>
            <p className="text-muted-foreground text-pretty">浏览所有构造做法、施工工艺和BIM模型资源</p>
          </div>

          <section className="mb-6 md:mb-8">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 md:gap-4">
              <Card className="glass-card glow-hover scale-in border-primary/30">
                <CardContent className="p-2.5 md:p-3 flex flex-col items-center justify-center text-center">
                  <FileText className="h-5 w-5 text-primary icon-glow-primary mb-1" />
                  <div className="text-2xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                    {mockKnowledgeEntries.length}
                  </div>
                  <p className="text-sm text-muted-foreground">知识条目</p>
                </CardContent>
              </Card>

              <Card className="glass-card glow-hover scale-in delay-100 border-accent/30">
                <CardContent className="p-2.5 md:p-3 flex flex-col items-center justify-center text-center">
                  <Layers className="h-5 w-5 text-accent icon-glow-accent mb-1" />
                  <div className="text-2xl font-bold bg-gradient-to-r from-accent via-info to-accent bg-clip-text text-transparent">
                    {mockKnowledgeEntries.filter((e) => e.rvtModel).length}
                  </div>
                  <p className="text-sm text-muted-foreground">3D模型</p>
                </CardContent>
              </Card>

              <Card className="glass-card glow-hover scale-in delay-200 border-info/30">
                <CardContent className="p-2.5 md:p-3 flex flex-col items-center justify-center text-center">
                  <FileImage className="h-5 w-5 text-info icon-glow-accent mb-1" />
                  <div className="text-2xl font-bold bg-gradient-to-r from-info via-primary to-info bg-clip-text text-transparent">
                    4
                  </div>
                  <p className="text-sm text-muted-foreground">2D图纸</p>
                </CardContent>
              </Card>

              <Card className="glass-card glow-hover scale-in delay-300 border-accent/30">
                <CardContent className="p-2.5 md:p-3 flex flex-col items-center justify-center text-center">
                  <ImageIcon className="h-5 w-5 text-accent icon-glow-accent mb-1" />
                  <div className="text-2xl font-bold bg-gradient-to-r from-accent via-primary to-accent bg-clip-text text-transparent">
                    4
                  </div>
                  <p className="text-sm text-muted-foreground">图片数量</p>
                </CardContent>
              </Card>

              <Card className="glass-card glow-hover scale-in delay-[400ms] border-primary/30">
                <CardContent className="p-2.5 md:p-3 flex flex-col items-center justify-center text-center">
                  <Eye className="h-5 w-5 text-primary icon-glow-primary mb-1" />
                  <div className="text-2xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                    {mockKnowledgeEntries.reduce((sum, e) => sum + e.views, 0)}
                  </div>
                  <p className="text-sm text-muted-foreground">总浏览量</p>
                </CardContent>
              </Card>
            </div>
          </section>

          <div className="grid lg:grid-cols-[280px_1fr] gap-6 lg:gap-8">
            <aside className="space-y-4">
              <KnowledgeFilters />
            </aside>

            <div>
              <KnowledgeGrid />
            </div>
          </div>
        </div>
      </main>

      <MobileNav />
    </div>
  )
}
