import { Header } from "@/components/header"
import { MobileNav } from "@/components/mobile-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import {
  ArrowLeft,
  Bookmark,
  Share2,
  Eye,
  Calendar,
  User,
  Download,
  Layers,
  FileText,
  ImageIcon,
  History,
  Package,
} from "lucide-react"
import Link from "next/link"
import {
  mockKnowledgeEntries,
  professionalLabels,
  componentTypeLabels,
  workProcessLabels,
  riskLevelLabels,
} from "@/lib/mock-data"
import { ModelViewer } from "@/components/model-viewer"
import { CADViewer } from "@/components/cad-viewer"
import { ImageGallery } from "@/components/image-gallery"
import { notFound } from "next/navigation"

export default async function KnowledgeDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  console.log("[v0] Looking for entry with ID:", id)
  console.log(
    "[v0] Available entries:",
    mockKnowledgeEntries.map((e) => ({ id: e.id, title: e.title })),
  )

  const entry = mockKnowledgeEntries.find((e) => e.id === id)

  if (!entry) {
    console.log("[v0] Entry not found for ID:", id)
    notFound()
  }

  console.log("[v0] Found entry:", entry.title)

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container px-4 md:px-6 lg:px-8 py-6 md:py-10 pb-24 md:pb-10">
        {/* Breadcrumb */}
        <div className="mb-5 md:mb-6">
          <Button variant="ghost" asChild className="mb-3 md:mb-4">
            <Link href="/knowledge">
              <ArrowLeft className="mr-2 h-4 w-4" />
              返回知识库
            </Link>
          </Button>
        </div>

        <div className="grid lg:grid-cols-[1fr_300px] xl:grid-cols-[1fr_340px] gap-6 md:gap-8 lg:gap-10">
          {/* Main Content */}
          <div className="space-y-5 md:space-y-6">
            {/* Header */}
            <div>
              <div className="flex flex-wrap gap-2 mb-3 md:mb-4">
                <Badge variant="outline">{professionalLabels[entry.professional]}</Badge>
                <Badge variant="outline">{componentTypeLabels[entry.componentType]}</Badge>
                <Badge variant="outline">{workProcessLabels[entry.workProcess]}</Badge>
                <Badge
                  variant={
                    entry.riskLevel === "high-risk"
                      ? "destructive"
                      : entry.riskLevel === "important"
                        ? "default"
                        : "secondary"
                  }
                >
                  {riskLevelLabels[entry.riskLevel]}
                </Badge>
              </div>

              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-3 md:mb-4 text-balance">{entry.title}</h1>

              <p className="text-base md:text-lg text-muted-foreground mb-5 md:mb-6 text-pretty leading-relaxed">
                {entry.description}
              </p>

              <div className="flex flex-wrap items-center gap-3 md:gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <User className="h-4 w-4" />
                  <span>{entry.createdBy}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  <span>{entry.updatedAt.toLocaleDateString("zh-CN")}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Eye className="h-4 w-4" />
                  <span>{entry.views} 次浏览</span>
                </div>
              </div>
            </div>

            <Separator />

            {/* Content Tabs */}
            <Tabs defaultValue={entry.rvtModel ? "model" : "content"} className="w-full">
              <TabsList className="grid w-full grid-cols-5 h-auto gap-1">
                {entry.rvtModel && (
                  <TabsTrigger
                    value="model"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    <Layers className="h-4 w-4 md:mr-2" />
                    <span className="hidden md:inline">3D模型</span>
                  </TabsTrigger>
                )}
                <TabsTrigger
                  value="content"
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  <FileText className="h-4 w-4 md:mr-2" />
                  <span className="hidden md:inline">内容</span>
                </TabsTrigger>
                {entry.cadFiles.length > 0 && (
                  <TabsTrigger
                    value="cad"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    <FileText className="h-4 w-4 md:mr-2" />
                    <span className="hidden md:inline">CAD图纸</span>
                  </TabsTrigger>
                )}
                {entry.images.length > 0 && (
                  <TabsTrigger
                    value="images"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    <ImageIcon className="h-4 w-4 md:mr-2" />
                    <span className="hidden md:inline">图片</span>
                  </TabsTrigger>
                )}
                <TabsTrigger
                  value="versions"
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  <History className="h-4 w-4 md:mr-2" />
                  <span className="hidden md:inline">版本</span>
                </TabsTrigger>
              </TabsList>

              {entry.rvtModel && (
                <TabsContent value="model" className="mt-5 md:mt-6">
                  <ModelViewer modelUrl={entry.rvtModel.url} />
                </TabsContent>
              )}

              <TabsContent value="content" className="mt-5 md:mt-6">
                <Card>
                  <CardContent className="p-5 md:p-8 lg:p-10">
                    <div className="prose prose-neutral dark:prose-invert max-w-none">
                      <div dangerouslySetInnerHTML={{ __html: entry.textContent.replace(/\n/g, "<br />") }} />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {entry.cadFiles.length > 0 && (
                <TabsContent value="cad" className="mt-5 md:mt-6">
                  <CADViewer files={entry.cadFiles} />
                </TabsContent>
              )}

              {entry.images.length > 0 && (
                <TabsContent value="images" className="mt-5 md:mt-6">
                  <ImageGallery images={entry.images} />
                </TabsContent>
              )}

              <TabsContent value="versions" className="mt-5 md:mt-6">
                <Card>
                  <CardContent className="p-5 md:p-6 lg:p-8">
                    <h3 className="text-base md:text-lg font-semibold mb-4">版本历史</h3>
                    <div className="space-y-4">
                      {[
                        {
                          version: "2.1",
                          date: "2025-01-15",
                          user: "张工",
                          changes: "更新机电管线排布说明，增加施工注意事项",
                        },
                        { version: "2.0", date: "2025-01-10", user: "李工", changes: "更新3D模型，优化构造节点细节" },
                        { version: "1.5", date: "2024-12-20", user: "王工", changes: "补充现场照片，修正CAD图纸标注" },
                        { version: "1.0", date: "2024-12-01", user: "张工", changes: "初始版本创建" },
                      ].map((v, index) => (
                        <div key={index} className="flex gap-3 md:gap-4 pb-4 border-b last:border-0">
                          <div className="flex-shrink-0">
                            <Badge variant={index === 0 ? "default" : "outline"}>v{v.version}</Badge>
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center gap-2 text-sm">
                              <span className="font-medium">{v.user}</span>
                              <span className="text-muted-foreground">·</span>
                              <span className="text-muted-foreground">{v.date}</span>
                              {index === 0 && (
                                <Badge variant="secondary" className="text-xs">
                                  当前版本
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">{v.changes}</p>
                            {index > 0 && (
                              <div className="flex gap-2 pt-2">
                                <Button variant="outline" size="sm">
                                  查看此版本
                                </Button>
                                <Button variant="outline" size="sm">
                                  对比差异
                                </Button>
                                <Button variant="outline" size="sm">
                                  恢复此版本
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <aside className="space-y-5">
            {/* Actions */}
            <Card>
              <CardContent className="p-5 space-y-3">
                <Button className="w-full" variant="default">
                  <Bookmark className="mr-2 h-4 w-4" />
                  收藏
                </Button>
                <Button className="w-full bg-transparent" variant="outline">
                  <Share2 className="mr-2 h-4 w-4" />
                  分享
                </Button>
                <Button className="w-full bg-transparent" variant="outline">
                  <Package className="mr-2 h-4 w-4" />
                  离线包下载
                </Button>
                <Button className="w-full bg-transparent" variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  下载全部资料
                </Button>
              </CardContent>
            </Card>

            {/* Tags */}
            <Card>
              <CardContent className="p-5">
                <h3 className="font-semibold mb-4 text-sm">标签</h3>
                <div className="flex flex-wrap gap-2">
                  {entry.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Attachments */}
            <Card>
              <CardContent className="p-5">
                <h3 className="font-semibold mb-4 text-sm">附件</h3>
                <div className="space-y-2.5 text-sm">
                  {entry.rvtModel && (
                    <div className="flex items-center justify-between p-2 rounded bg-muted">
                      <div className="flex items-center gap-2">
                        <Layers className="h-4 w-4 text-muted-foreground" />
                        <span className="truncate">{entry.rvtModel.name}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {(entry.rvtModel.size / 1024 / 1024).toFixed(1)}MB
                      </span>
                    </div>
                  )}
                  {entry.cadFiles.map((file) => (
                    <div key={file.id} className="flex items-center justify-between p-2 rounded bg-muted">
                      <div className="flex items-center gap-2 min-w-0">
                        <FileText className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="truncate">{file.name}</span>
                      </div>
                      <span className="text-xs text-muted-foreground flex-shrink-0">
                        {(file.size / 1024 / 1024).toFixed(1)}MB
                      </span>
                    </div>
                  ))}
                  {entry.images.map((file) => (
                    <div key={file.id} className="flex items-center justify-between p-2 rounded bg-muted">
                      <div className="flex items-center gap-2 min-w-0">
                        <ImageIcon className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="truncate">{file.name}</span>
                      </div>
                      <span className="text-xs text-muted-foreground flex-shrink-0">
                        {(file.size / 1024).toFixed(0)}KB
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Version Info */}
            <Card>
              <CardContent className="p-5">
                <h3 className="font-semibold mb-4 text-sm">版本信息</h3>
                <div className="space-y-2.5 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">当前版本</span>
                    <span className="font-medium">v{entry.version}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">状态</span>
                    <Badge variant="outline" className="text-xs">
                      {entry.status === "published" ? "已发布" : entry.status}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">访问范围</span>
                    <span className="font-medium">
                      {entry.accessScope === "company" ? "全公司" : entry.accessScope === "project" ? "项目" : "部门"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </aside>
        </div>
      </main>

      <MobileNav />
    </div>
  )
}
