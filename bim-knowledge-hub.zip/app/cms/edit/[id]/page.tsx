import { Header } from "@/components/header"
import { KnowledgeEntryForm } from "@/components/knowledge-entry-form"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { mockKnowledgeEntries } from "@/lib/mock-data"
import { notFound } from "next/navigation"

export default async function EditEntryPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const entry = mockKnowledgeEntries.find((e) => e.id === id)

  if (!entry) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-8">
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/cms">
            <ArrowLeft className="mr-2 h-4 w-4" />
            返回内容管理
          </Link>
        </Button>

        <div className="max-w-4xl">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">编辑知识条目</h1>
            <p className="text-muted-foreground">修改知识条目内容并保存</p>
          </div>

          <KnowledgeEntryForm mode="edit" entry={entry} />
        </div>
      </main>
    </div>
  )
}
