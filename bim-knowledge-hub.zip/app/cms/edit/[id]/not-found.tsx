import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { FileQuestion } from "lucide-react"
import Link from "next/link"

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container py-16">
        <div className="flex flex-col items-center justify-center text-center">
          <FileQuestion className="h-24 w-24 text-muted-foreground mb-6" />
          <h1 className="text-3xl font-bold mb-2">条目未找到</h1>
          <p className="text-muted-foreground mb-6">您要编辑的知识条目不存在或已被删除</p>
          <Button asChild>
            <Link href="/cms">返回内容管理</Link>
          </Button>
        </div>
      </main>
    </div>
  )
}
