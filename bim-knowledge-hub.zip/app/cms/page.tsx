import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, FileText, Clock, CheckCircle2, AlertCircle } from "lucide-react"
import Link from "next/link"
import { CMSContentList } from "@/components/cms-content-list"
import { mockKnowledgeEntries } from "@/lib/mock-data"

export default function CMSPage() {
  const draftCount = mockKnowledgeEntries.filter((e) => e.status === "draft").length
  const reviewCount = mockKnowledgeEntries.filter((e) => e.status === "review").length
  const publishedCount = mockKnowledgeEntries.filter((e) => e.status === "published").length

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-6 md:py-10 pb-10">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">内容管理</h1>
            <p className="text-muted-foreground">创建、编辑和管理知识库条目</p>
          </div>
          <Button asChild size="lg">
            <Link href="/cms/create">
              <Plus className="mr-2 h-5 w-5" />
              创建条目
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-8">
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <FileText className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold mb-1">{mockKnowledgeEntries.length}</div>
              <p className="text-sm text-muted-foreground">总条目数</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <Clock className="h-5 w-5 text-amber-500" />
              </div>
              <div className="text-2xl font-bold mb-1">{draftCount}</div>
              <p className="text-sm text-muted-foreground">草稿</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <AlertCircle className="h-5 w-5 text-blue-500" />
              </div>
              <div className="text-2xl font-bold mb-1">{reviewCount}</div>
              <p className="text-sm text-muted-foreground">待审核</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              </div>
              <div className="text-2xl font-bold mb-1">{publishedCount}</div>
              <p className="text-sm text-muted-foreground">已发布</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-4">
            <TabsTrigger value="all">全部</TabsTrigger>
            <TabsTrigger value="draft">草稿</TabsTrigger>
            <TabsTrigger value="review">待审核</TabsTrigger>
            <TabsTrigger value="published">已发布</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            <CMSContentList entries={mockKnowledgeEntries} />
          </TabsContent>

          <TabsContent value="draft" className="mt-6">
            <CMSContentList entries={mockKnowledgeEntries.filter((e) => e.status === "draft")} />
          </TabsContent>

          <TabsContent value="review" className="mt-6">
            <CMSContentList entries={mockKnowledgeEntries.filter((e) => e.status === "review")} />
          </TabsContent>

          <TabsContent value="published" className="mt-6">
            <CMSContentList entries={mockKnowledgeEntries.filter((e) => e.status === "published")} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
