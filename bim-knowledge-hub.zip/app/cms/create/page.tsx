import { Header } from "@/components/header"
import { KnowledgeEntryForm } from "@/components/knowledge-entry-form"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function CreateEntryPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-8">
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/cms">
            <ArrowLeft className="mr-2 h-4 w-4" />
            返回内容管理
          </Link>
        </Button>

        <div className="max-w-4xl">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">创建知识条目</h1>
            <p className="text-muted-foreground">填写下方表单创建新的知识库条目</p>
          </div>

          <KnowledgeEntryForm mode="create" />
        </div>
      </main>
    </div>
  )
}
