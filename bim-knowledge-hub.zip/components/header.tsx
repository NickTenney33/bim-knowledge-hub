"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from "@/components/ui/dropdown-menu"
import { ThemeSwitcher } from "@/components/theme-switcher"
import { AISearchDrawer } from "@/components/ai-search-drawer"
import { Menu, User, Sparkles, Shield, UserCircle } from "lucide-react"
import { useState } from "react"
import { useUserRole } from "@/contexts/user-role-context"

export function Header() {
  const [aiDrawerOpen, setAiDrawerOpen] = useState(false)
  const { role, setRole, isLoaded } = useUserRole()

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b glass-nav">
        <div className="container flex h-16 md:h-20 items-center justify-between gap-3 px-4 md:px-6 lg:px-8">
          <div className="flex items-center gap-4 md:gap-8 min-w-0">
            <Link href="/" className="flex items-center gap-2 flex-shrink-0 group">
              <div className="flex h-8 w-8 md:h-10 md:w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent text-primary-foreground font-bold text-base md:text-xl shadow-lg group-hover:shadow-[0_0_20px_rgba(59,130,246,0.5)] transition-all duration-300">
                BIM
              </div>
              <span className="hidden font-semibold text-lg md:text-xl sm:inline-block truncate bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                三维知识库
              </span>
            </Link>

            <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-sm md:text-base">
              <Link
                href="/"
                className="text-foreground/80 hover:text-foreground transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(59,130,246,0.6)] py-2"
              >
                首页
              </Link>
              <Link
                href="/knowledge"
                className="text-foreground/80 hover:text-foreground transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(59,130,246,0.6)] py-2"
              >
                知识库
              </Link>
              {isLoaded && role === "admin" && (
                <>
                  <Link
                    href="/cms"
                    className="text-foreground/80 hover:text-foreground transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(59,130,246,0.6)] py-2"
                  >
                    内容管理
                  </Link>
                  <Link
                    href="/admin"
                    className="text-foreground/80 hover:text-foreground transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(59,130,246,0.6)] py-2"
                  >
                    系统管理
                  </Link>
                </>
              )}
            </nav>
          </div>

          <div className="flex items-center gap-2 md:gap-3 flex-shrink-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setAiDrawerOpen(true)}
              className="hidden sm:flex items-center gap-2 hover:bg-accent/10 hover:border-accent transition-all duration-300"
            >
              <Sparkles className="h-4 w-4" />
              <span>AI问答</span>
            </Button>

            <ThemeSwitcher />

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="hover:scale-110 transition-transform duration-300">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel>用户角色</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuRadioGroup value={role} onValueChange={(value) => setRole(value as "user" | "admin")}>
                  <DropdownMenuRadioItem value="user" className="cursor-pointer">
                    <UserCircle className="mr-2 h-4 w-4" />
                    普通用户
                  </DropdownMenuRadioItem>
                  <DropdownMenuRadioItem value="admin" className="cursor-pointer">
                    <Shield className="mr-2 h-4 w-4" />
                    管理员
                  </DropdownMenuRadioItem>
                </DropdownMenuRadioGroup>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="ghost" size="icon" className="md:hidden hover:scale-110 transition-transform duration-300">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <AISearchDrawer open={aiDrawerOpen} onOpenChange={setAiDrawerOpen} />
    </>
  )
}
