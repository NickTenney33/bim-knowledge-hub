"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Sparkles, Send, User, Bot, Loader2, X, ImageIcon } from "lucide-react"
import { Input } from "@/components/ui/input"

interface Message {
  role: "user" | "assistant"
  content: string
  image?: string
}

interface AISearchDrawerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function AISearchDrawer({ open, onOpenChange }: AISearchDrawerProps) {
  const { toast } = useToast()
  const [query, setQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "文件过大",
          description: "图片大小不能超过10MB",
          variant: "destructive",
        })
        return
      }

      const reader = new FileReader()
      reader.onloadend = () => {
        setUploadedImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if ((!query.trim() && !uploadedImage) || isLoading) return

    const userMessage = query.trim() || "请识别这张图片"
    const userImage = uploadedImage
    setIsLoading(true)

    const newMessages = [...messages, { role: "user" as const, content: userMessage, image: userImage || undefined }]
    setMessages(newMessages)
    setQuery("")
    setUploadedImage(null)

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content,
            ...(m.image && { image: m.image }),
          })),
        }),
      })

      const data = await response.json()

      if (!response.ok || data.error) {
        let fallbackMessage = "AI服务暂时不可用，请稍后重试"
        if (response.status === 401 || response.status === 503) {
          fallbackMessage = `⚠️ ${data.message || "AI功能需要配置"}\n\n请在环境变量中配置 EVOLINK_API_KEY 以启用完整功能。`
        }

        setMessages((prev) => [...prev, { role: "assistant", content: fallbackMessage }])

        toast({
          title: "AI功能未配置",
          description: data.message || "请配置环境变量",
          variant: "destructive",
        })
        return
      }

      setMessages((prev) => [...prev, { role: "assistant", content: data.message }])
    } catch (error) {
      console.error("[v0] AI chat error:", error)
      setMessages((prev) => [...prev, { role: "assistant", content: "抱歉，处理您的问题时遇到了错误。请稍后重试。" }])

      toast({
        title: "请求失败",
        description: "无法连接到AI服务",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-xl flex flex-col p-0">
        <SheetHeader className="px-6 py-4 border-b">
          <SheetTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-accent" />
            AI智能助手
          </SheetTitle>
          <SheetDescription>用自然语言提问，获取专业的构造做法和施工要点解答</SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {messages.length === 0 && (
            <Card className="border-2 border-dashed">
              <CardContent className="p-6 text-center space-y-3">
                <Sparkles className="h-10 w-10 mx-auto text-muted-foreground" />
                <div>
                  <h3 className="font-semibold mb-1">开始对话</h3>
                  <p className="text-sm text-muted-foreground">询问关于构造做法、施工工艺等问题</p>
                </div>
                <div className="flex flex-wrap gap-2 justify-center">
                  {["楼板裂缝如何预防？", "钢筋搭接长度要求？"].map((example) => (
                    <Badge
                      key={example}
                      variant="secondary"
                      className="cursor-pointer hover:bg-secondary/80"
                      onClick={() => setQuery(example)}
                    >
                      {example}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex gap-3 animate-in fade-in-0 slide-in-from-bottom-2 duration-300 ${
                message.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              {message.role === "assistant" && (
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-accent/10 flex-shrink-0">
                  <Bot className="h-5 w-5 text-accent" />
                </div>
              )}

              <Card className={`max-w-[80%] ${message.role === "user" ? "bg-primary text-primary-foreground" : ""}`}>
                <CardContent className="p-4 space-y-2">
                  {message.image && (
                    <img
                      src={message.image || "/placeholder.svg"}
                      alt="上传的图片"
                      className="rounded-md max-w-full h-auto max-h-32 object-contain"
                    />
                  )}
                  <p className="text-sm whitespace-pre-line leading-relaxed">{message.content}</p>
                </CardContent>
              </Card>

              {message.role === "user" && (
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary flex-shrink-0">
                  <User className="h-5 w-5 text-primary-foreground" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 justify-start animate-in fade-in-0 duration-200">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-accent/10 flex-shrink-0">
                <Bot className="h-5 w-5 text-accent" />
              </div>
              <Card>
                <CardContent className="p-4 flex items-center gap-2">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">正在思考...</span>
                </CardContent>
              </Card>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        <div className="px-6 py-4 border-t bg-background">
          <form onSubmit={handleSubmit} className="space-y-3">
            {uploadedImage && (
              <div className="relative inline-block">
                <img
                  src={uploadedImage || "/placeholder.svg"}
                  alt="待上传"
                  className="rounded-md max-h-24 object-contain border-2 border-primary"
                />
                <Button
                  type="button"
                  size="icon"
                  variant="destructive"
                  className="absolute -top-2 -right-2 h-6 w-6 rounded-full"
                  onClick={() => setUploadedImage(null)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}

            <div className="flex gap-2">
              <Textarea
                placeholder={uploadedImage ? "描述图片或提出问题..." : "输入您的问题..."}
                className="min-h-[60px] resize-none"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault()
                    handleSubmit(e)
                  }
                }}
                disabled={isLoading}
              />
              <div className="flex flex-col gap-2">
                <Input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageUpload}
                  disabled={isLoading}
                />
                <Button
                  type="button"
                  size="icon"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isLoading}
                >
                  <ImageIcon className="h-5 w-5" />
                </Button>
                <Button type="submit" size="icon" disabled={(!query.trim() && !uploadedImage) || isLoading}>
                  {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
                </Button>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Enter 发送 · Shift + Enter 换行</p>
          </form>
        </div>
      </SheetContent>
    </Sheet>
  )
}
