"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { FileText, ZoomIn, ZoomOut, Maximize2, Layers, Ruler, RotateCcw, Download, Pencil } from "lucide-react"
import type { FileAttachment } from "@/lib/types"

interface CADViewerProps {
  files: FileAttachment[]
}

export function CADViewer({ files }: CADViewerProps) {
  const [zoom, setZoom] = useState(100)
  const [showLayers, setShowLayers] = useState(true)
  const [measureMode, setMeasureMode] = useState(false)
  const [annotationMode, setAnnotationMode] = useState(false)

  const [layers, setLayers] = useState([
    { name: "建筑", visible: true, color: "#FF0000" },
    { name: "结构", visible: true, color: "#0000FF" },
    { name: "尺寸标注", visible: true, color: "#00FF00" },
    { name: "轴线", visible: true, color: "#FFFF00" },
    { name: "文字说明", visible: false, color: "#FF00FF" },
  ])

  if (files.length === 0) {
    return (
      <Card className="p-8 text-center">
        <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
        <p className="text-muted-foreground">暂无CAD图纸</p>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {files.map((file) => (
        <Card key={file.id} className="overflow-hidden">
          <div className="relative aspect-video bg-muted flex items-center justify-center">
            <div className="text-center p-8">
              <FileText className="h-16 w-16 mx-auto mb-4 text-primary" />
              <h3 className="text-lg font-semibold mb-2">CAD图纸查看器</h3>
              <p className="text-sm text-muted-foreground mb-2">{file.name}</p>
              <p className="text-xs text-muted-foreground">实际项目中将集成Autodesk Viewer或轻量CAD组件</p>
              <div className="mt-4 space-y-2 text-xs text-muted-foreground">
                <p>支持功能：缩放 / 平移 / 测量 / 图层控制 / 批注</p>
                {measureMode && <Badge variant="secondary">测量模式已开启</Badge>}
                {annotationMode && <Badge variant="secondary">批注模式已开启</Badge>}
              </div>
            </div>

            <div className="absolute top-4 right-4 flex flex-col gap-2">
              <Button size="icon" variant="secondary" onClick={() => setZoom(Math.min(200, zoom + 10))}>
                <ZoomIn className="h-4 w-4" />
              </Button>
              <Button size="icon" variant="secondary" onClick={() => setZoom(Math.max(50, zoom - 10))}>
                <ZoomOut className="h-4 w-4" />
              </Button>
              <Button size="icon" variant="secondary" onClick={() => setZoom(100)}>
                <RotateCcw className="h-4 w-4" />
              </Button>

              <Button
                size="icon"
                variant={measureMode ? "default" : "secondary"}
                onClick={() => setMeasureMode(!measureMode)}
                title="测量工具"
              >
                <Ruler className="h-4 w-4" />
              </Button>

              <Button
                size="icon"
                variant={annotationMode ? "default" : "secondary"}
                onClick={() => setAnnotationMode(!annotationMode)}
                title="批注工具"
              >
                <Pencil className="h-4 w-4" />
              </Button>

              <Popover>
                <PopoverTrigger asChild>
                  <Button size="icon" variant="secondary" title="图层控制">
                    <Layers className="h-4 w-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-72" align="end">
                  <div className="space-y-4">
                    <h4 className="font-semibold text-sm">图层控制</h4>
                    <div className="space-y-3">
                      {layers.map((layer, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-4 h-4 rounded border" style={{ backgroundColor: layer.color }} />
                            <Label className="text-sm font-normal">{layer.name}</Label>
                          </div>
                          <Switch
                            checked={layer.visible}
                            onCheckedChange={(checked) => {
                              const newLayers = [...layers]
                              newLayers[index].visible = checked
                              setLayers(newLayers)
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </PopoverContent>
              </Popover>

              <Button size="icon" variant="secondary">
                <Maximize2 className="h-4 w-4" />
              </Button>
            </div>

            <div className="absolute bottom-4 left-4 bg-background/90 backdrop-blur px-3 py-2 rounded-md text-sm font-medium">
              {zoom}%
            </div>
          </div>

          <div className="p-4 border-t border-border space-y-3">
            <div className="flex items-center gap-4">
              <Label className="text-sm">缩放比例</Label>
              <Slider
                value={[zoom]}
                onValueChange={(value) => setZoom(value[0])}
                min={50}
                max={200}
                step={10}
                className="flex-1"
              />
              <span className="text-sm font-medium min-w-[3rem] text-right">{zoom}%</span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <div className="flex gap-4">
                <div>
                  <span className="text-muted-foreground">文件大小:</span>
                  <span className="ml-2 font-medium">{(file.size / 1024 / 1024).toFixed(2)} MB</span>
                </div>
                <div>
                  <span className="text-muted-foreground">格式:</span>
                  <span className="ml-2 font-medium">{file.name.split(".").pop()?.toUpperCase()}</span>
                </div>
              </div>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                下载原文件
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
