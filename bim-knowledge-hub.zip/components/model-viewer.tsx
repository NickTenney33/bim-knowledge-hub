"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Switch } from "@/components/ui/switch"
import { ZoomIn, ZoomOut, RotateCcw, Maximize2, Layers, Box, Loader2 } from "lucide-react"

interface ModelViewerProps {
  modelUrl: string
}

export function ModelViewer({ modelUrl }: ModelViewerProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [isExploded, setIsExploded] = useState(false)
  const [explodeLevel, setExplodeLevel] = useState(0)
  const [componentFilters, setComponentFilters] = useState([
    { name: "结构构件", visible: true },
    { name: "建筑构件", visible: true },
    { name: "机电设备", visible: true },
    { name: "装饰装修", visible: false },
  ])

  const isCloudBIMModel = modelUrl.includes("cloudbimcdn.com")
  const viewerUrl = isCloudBIMModel ? modelUrl : null

  useEffect(() => {
    if (viewerUrl) {
      setIsLoading(true)
      setLoadingProgress(0)

      // Simulate progressive loading
      const interval = setInterval(() => {
        setLoadingProgress((prev) => {
          if (prev >= 90) {
            clearInterval(interval)
            return 90
          }
          return prev + Math.random() * 15
        })
      }, 300)

      return () => clearInterval(interval)
    }
  }, [viewerUrl])

  const handleIframeLoad = () => {
    setLoadingProgress(100)
    setTimeout(() => {
      setIsLoading(false)
    }, 500)
  }

  return (
    <Card className="overflow-hidden border-2 border-border">
      <div className="relative aspect-video bg-gradient-to-br from-[#0a0e27] via-[#0f1629] to-[#1a1f3a] flex items-center justify-center overflow-hidden">
        {isLoading && viewerUrl && (
          <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-[#0a0e27]/95 via-[#0f1629]/95 to-[#1a1f3a]/95 backdrop-blur-sm">
            <div className="relative mb-6">
              <Loader2 className="h-16 w-16 text-accent animate-spin" />
              <div className="absolute inset-0 animate-ping opacity-20">
                <div className="h-16 w-16 rounded-full bg-accent" />
              </div>
            </div>

            <h3 className="text-lg font-semibold text-white mb-4 animate-pulse">正在加载3D模型...</h3>

            <div className="w-64 space-y-2">
              <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-accent via-primary to-accent animate-shimmer bg-[length:200%_100%] transition-all duration-500 ease-out rounded-full shadow-[0_0_20px_rgba(99,102,241,0.5)]"
                  style={{ width: `${loadingProgress}%` }}
                />
              </div>
              <p className="text-center text-sm text-gray-400">{Math.round(loadingProgress)}%</p>
            </div>

            <p className="text-xs text-gray-500 mt-4">CloudBIM轻量化模型</p>
          </div>
        )}

        {viewerUrl ? (
          <>
            <div className="absolute inset-0 overflow-hidden">
              <iframe
                src={viewerUrl}
                className="absolute w-full border-0"
                style={{
                  top: "-60px",
                  height: "calc(100% + 60px)",
                  left: 0,
                  right: 0,
                }}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title="3D模型查看器"
                onLoad={handleIframeLoad}
              />
            </div>
          </>
        ) : (
          <>
            {/* Animated background elements */}
            <div className="absolute inset-0 opacity-30">
              <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-accent/20 rounded-full blur-3xl animate-pulse" />
              <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse delay-1000" />
            </div>

            <div className="relative text-center p-8 z-10">
              <div className="relative inline-block mb-4">
                <Maximize2 className="h-16 w-16 mx-auto text-[var(--color-viewer-highlight)] drop-shadow-[0_0_20px_rgba(99,102,241,0.5)]" />
                <div className="absolute inset-0 animate-ping opacity-20">
                  <Maximize2 className="h-16 w-16 mx-auto text-accent" />
                </div>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2 drop-shadow-lg">3D模型查看器</h3>
              {isCloudBIMModel ? (
                <>
                  <p className="text-sm text-gray-300 mb-2">CloudBIM轻量化模型</p>
                  <p className="text-xs text-gray-400 mb-4 font-mono break-all px-4">{modelUrl}</p>
                  <Badge variant="secondary" className="bg-red-500/20 text-red-400 border-red-400/40">
                    无法加载模型
                  </Badge>
                </>
              ) : (
                <>
                  <p className="text-sm text-gray-300 mb-4">实际项目中将使用Three.js加载glTF轻量化模型</p>
                  <p className="text-xs text-gray-400 mb-2 font-mono">{modelUrl}</p>
                </>
              )}
              <div className="mt-4 space-y-2">
                {isExploded && (
                  <Badge
                    variant="secondary"
                    className="bg-accent/20 text-accent border-accent/40 shadow-[0_0_20px_rgba(99,102,241,0.3)]"
                  >
                    爆炸视图 - 分解度 {explodeLevel}%
                  </Badge>
                )}
              </div>
            </div>
          </>
        )}

        {!viewerUrl && (
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <Button
              size="icon"
              variant="secondary"
              className="glass-card hover:glow-border transition-all duration-300"
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button
              size="icon"
              variant="secondary"
              className="glass-card hover:glow-border transition-all duration-300"
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button
              size="icon"
              variant="secondary"
              className="glass-card hover:glow-border transition-all duration-300"
            >
              <RotateCcw className="h-4 w-4" />
            </Button>

            <Popover>
              <PopoverTrigger asChild>
                <Button
                  size="icon"
                  variant="secondary"
                  className="glass-card hover:glow-border transition-all duration-300"
                >
                  <Layers className="h-4 w-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-64 glass-card" align="end">
                <div className="space-y-4">
                  <h4 className="font-semibold text-sm">构件筛选</h4>
                  <div className="space-y-3">
                    {componentFilters.map((filter, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <Label className="text-sm font-normal">{filter.name}</Label>
                        <Switch
                          checked={filter.visible}
                          onCheckedChange={(checked) => {
                            const newFilters = [...componentFilters]
                            newFilters[index].visible = checked
                            setComponentFilters(newFilters)
                          }}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </PopoverContent>
            </Popover>

            <Popover>
              <PopoverTrigger asChild>
                <Button
                  size="icon"
                  variant={isExploded ? "default" : "secondary"}
                  className="glass-card hover:glow-border transition-all duration-300"
                >
                  <Box className="h-4 w-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-72 glass-card" align="end">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-semibold">爆炸视图</Label>
                    <Button
                      size="sm"
                      variant={isExploded ? "default" : "outline"}
                      onClick={() => {
                        setIsExploded(!isExploded)
                        if (!isExploded) setExplodeLevel(50)
                        else setExplodeLevel(0)
                      }}
                    >
                      {isExploded ? "关闭" : "开启"}
                    </Button>
                  </div>
                  {isExploded && (
                    <div className="space-y-2">
                      <Label className="text-xs">分解度: {explodeLevel}%</Label>
                      <Slider
                        value={[explodeLevel]}
                        onValueChange={(value) => setExplodeLevel(value[0])}
                        min={0}
                        max={100}
                        step={10}
                        className="flex-1"
                      />
                    </div>
                  )}
                </div>
              </PopoverContent>
            </Popover>

            <Button
              size="icon"
              variant="secondary"
              className="glass-card hover:glow-border transition-all duration-300"
            >
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-border">
        <div className="flex items-center justify-between text-sm">
          <div className="flex gap-4">
            <div>
              <span className="text-muted-foreground">构件总数:</span>
              <span className="ml-2 font-medium">128</span>
            </div>
            <div>
              <span className="text-muted-foreground">当前楼层:</span>
              <span className="ml-2 font-medium">1F</span>
            </div>
            <div>
              <span className="text-muted-foreground">可见构件:</span>
              <span className="ml-2 font-medium">
                {componentFilters.filter((f) => f.visible).length} / {componentFilters.length} 类
              </span>
            </div>
          </div>
          <Button variant="outline" size="sm">
            构件查询
          </Button>
        </div>
      </div>
    </Card>
  )
}
