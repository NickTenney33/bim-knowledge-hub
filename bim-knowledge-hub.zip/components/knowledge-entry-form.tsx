"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Upload, X, Save, Send, Eye } from "lucide-react"
import type { KnowledgeEntry } from "@/lib/types"
import { professionalLabels, componentTypeLabels, workProcessLabels, riskLevelLabels } from "@/lib/mock-data"

interface KnowledgeEntryFormProps {
  mode: "create" | "edit"
  entry?: KnowledgeEntry
}

export function KnowledgeEntryForm({ mode, entry }: KnowledgeEntryFormProps) {
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({})
  const [tags, setTags] = useState<string[]>(entry?.tags || [])
  const [tagInput, setTagInput] = useState("")

  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()])
      setTagInput("")
    }
  }

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
  }

  const simulateUpload = (fileType: string) => {
    let progress = 0
    const interval = setInterval(() => {
      progress += 10
      setUploadProgress((prev) => ({ ...prev, [fileType]: progress }))
      if (progress >= 100) {
        clearInterval(interval)
        setTimeout(() => {
          setUploadProgress((prev) => {
            const newProgress = { ...prev }
            delete newProgress[fileType]
            return newProgress
          })
        }, 1000)
      }
    }, 200)
  }

  return (
    <form className="space-y-6">
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>基本信息</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">标题 *</Label>
            <Input id="title" placeholder="输入知识条目标题" defaultValue={entry?.title} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">描述 *</Label>
            <Textarea
              id="description"
              placeholder="简要描述该知识条目的内容"
              rows={3}
              defaultValue={entry?.description}
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>专业 *</Label>
              <Select defaultValue={entry?.professional || ""}>
                <SelectTrigger>
                  <SelectValue placeholder="选择专业" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(professionalLabels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>构造部位 *</Label>
              <Select defaultValue={entry?.componentType || ""}>
                <SelectTrigger>
                  <SelectValue placeholder="选择构造部位" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(componentTypeLabels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>工序 *</Label>
              <Select defaultValue={entry?.workProcess || ""}>
                <SelectTrigger>
                  <SelectValue placeholder="选择工序" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(workProcessLabels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>风险等级 *</Label>
              <Select defaultValue={entry?.riskLevel || ""}>
                <SelectTrigger>
                  <SelectValue placeholder="选择风险等级" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(riskLevelLabels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>标签</Label>
            <div className="flex gap-2 mb-2">
              <Input
                placeholder="添加标签后按回车"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault()
                    addTag()
                  }
                }}
              />
              <Button type="button" variant="outline" onClick={addTag}>
                添加
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {tags.map((tag, index) => (
                <Badge key={index} variant="secondary">
                  {tag}
                  <button className="ml-1" type="button" onClick={() => removeTag(tag)}>
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>详细内容</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="content">构造做法说明 *</Label>
            <Textarea
              id="content"
              placeholder="详细描述构造做法、施工要点、质量标准等（支持Markdown格式）"
              rows={8}
              defaultValue={entry?.textContent}
              className="font-mono text-sm"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="usage-area">使用区域</Label>
            <Textarea id="usage-area" placeholder="说明该构造做法适用的区域和场景，如：地下室、屋面、外墙等" rows={3} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="precautions">注意事项</Label>
            <Textarea id="precautions" placeholder="列出施工中需要特别注意的事项、常见错误及预防措施" rows={4} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="typical-issues">典型问题与风险提示</Label>
            <Textarea id="typical-issues" placeholder="说明可能出现的质量问题、安全风险及应对措施" rows={4} />
          </div>

          <p className="text-xs text-muted-foreground">支持Markdown格式：使用 # 标题、- 列表、**粗体**、*斜体* 等</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>附件上传</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>3D模型 (.rvt)</Label>
            <div
              className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer"
              onClick={() => simulateUpload("rvt")}
            >
              <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm text-muted-foreground mb-1">点击上传或拖拽Revit模型文件</p>
              <p className="text-xs text-muted-foreground mb-2">支持 .rvt 格式，最大 100MB</p>
              <p className="text-xs text-amber-600">上传后将自动转换为glTF轻量化模型</p>
            </div>
            {uploadProgress["rvt"] !== undefined && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>正在上传...</span>
                  <span>{uploadProgress["rvt"]}%</span>
                </div>
                <Progress value={uploadProgress["rvt"]} />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>CAD图纸 (.dwg / .dxf)</Label>
            <div
              className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer"
              onClick={() => simulateUpload("cad")}
            >
              <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm text-muted-foreground mb-1">点击上传或拖拽CAD图纸</p>
              <p className="text-xs text-muted-foreground">支持 .dwg、.dxf 格式，可上传多个文件</p>
            </div>
            {uploadProgress["cad"] !== undefined && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>正在上传...</span>
                  <span>{uploadProgress["cad"]}%</span>
                </div>
                <Progress value={uploadProgress["cad"]} />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>现场照片 (.jpg / .png)</Label>
            <div
              className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer"
              onClick={() => simulateUpload("image")}
            >
              <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm text-muted-foreground mb-1">点击上传或拖拽图片</p>
              <p className="text-xs text-muted-foreground mb-2">支持 .jpg、.png 格式，可上传多个文件</p>
              <p className="text-xs text-blue-600">可标记为"标准示例"或"现场对比"用于对照展示</p>
            </div>
            {uploadProgress["image"] !== undefined && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>正在上传...</span>
                  <span>{uploadProgress["image"]}%</span>
                </div>
                <Progress value={uploadProgress["image"]} />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>发布设置</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>访问范围</Label>
            <Select defaultValue={entry?.accessScope || "company"}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="department">部门级（仅本部门可见）</SelectItem>
                <SelectItem value="project">项目级（指定项目可见）</SelectItem>
                <SelectItem value="company">企业级（全公司可见）</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {mode === "edit" && (
            <div className="space-y-2">
              <Label htmlFor="version-notes">版本更新说明</Label>
              <Textarea
                id="version-notes"
                placeholder="描述本次更新的主要内容，如：更新了3D模型细节、补充了施工注意事项等"
                rows={3}
              />
              <p className="text-xs text-muted-foreground">将自动生成新版本号，并保留历史版本记录</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-between items-center pt-4 border-t border-border">
        <Button type="button" variant="outline" asChild>
          <a href="/cms">取消</a>
        </Button>

        <div className="flex gap-2">
          <Button type="button" variant="outline">
            <Eye className="mr-2 h-4 w-4" />
            预览
          </Button>
          <Button type="button" variant="outline">
            <Save className="mr-2 h-4 w-4" />
            保存草稿
          </Button>
          <Button type="submit">
            <Send className="mr-2 h-4 w-4" />
            {mode === "create" ? "提交审核" : "更新并发布"}
          </Button>
        </div>
      </div>
    </form>
  )
}
