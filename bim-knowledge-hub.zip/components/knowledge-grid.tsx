"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Eye, Layers, FileText, ChevronRight } from "lucide-react"
import Link from "next/link"
import { mockKnowledgeEntries, professionalLabels, riskLevelLabels } from "@/lib/mock-data"

export function KnowledgeGrid() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">共 {mockKnowledgeEntries.length} 条结果</p>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="glow-hover border-accent/50 bg-transparent">
            最新
          </Button>
          <Button variant="ghost" size="sm" className="hover:text-accent">
            最热
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {mockKnowledgeEntries.map((entry, index) => (
          <Card
            key={entry.id}
            className="glass-card glow-hover slide-in border-accent/30 overflow-hidden"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            {/* Header section with compact padding */}
            <CardHeader className="p-4 pb-3 space-y-2.5">
              {/* Top badges row - reduced spacing */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <Badge
                    variant="outline"
                    className="border-primary/50 bg-gradient-to-r from-primary/10 to-accent/10 text-xs px-2 py-0.5"
                  >
                    {professionalLabels[entry.professional]}
                  </Badge>
                  {entry.rvtModel && (
                    <Badge
                      variant="secondary"
                      className="bg-gradient-to-r from-accent/20 to-info/20 border-accent/50 text-xs px-2 py-0.5"
                    >
                      <Layers className="h-3 w-3 mr-1 icon-glow-accent" />
                      3D
                    </Badge>
                  )}
                </div>
                <Badge
                  variant={
                    entry.riskLevel === "high-risk"
                      ? "destructive"
                      : entry.riskLevel === "important"
                        ? "default"
                        : "secondary"
                  }
                  className={`text-xs px-2 py-0.5 ${
                    entry.riskLevel === "high-risk"
                      ? "shadow-[0_0_12px_rgba(239,68,68,0.4)]"
                      : entry.riskLevel === "important"
                        ? "shadow-[0_0_12px_rgba(59,130,246,0.4)]"
                        : "shadow-sm"
                  }`}
                >
                  {riskLevelLabels[entry.riskLevel]}
                </Badge>
              </div>

              {/* Title - larger and bold */}
              <CardTitle className="text-lg font-semibold line-clamp-1 text-balance hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-primary hover:to-accent transition-all duration-300">
                {entry.title}
              </CardTitle>

              {/* Description - compact */}
              <CardDescription className="line-clamp-2 text-sm text-pretty leading-relaxed">
                {entry.description}
              </CardDescription>
            </CardHeader>

            {/* Content section - reduced padding */}
            <CardContent className="p-4 pt-0 space-y-3">
              {/* Tags row - smaller badges */}
              <div className="flex flex-wrap gap-1.5">
                {entry.tags.slice(0, 4).map((tag, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="text-xs px-2 py-0.5 border-accent/30 hover:border-accent/60 transition-colors"
                  >
                    {tag}
                  </Badge>
                ))}
              </div>

              {/* Bottom action bar with border separator */}
              <div className="flex items-center justify-between pt-3 border-t border-border/50">
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Eye className="h-3.5 w-3.5" />
                    <span>{entry.views}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <FileText className="h-3.5 w-3.5" />
                    <span>{entry.cadFiles.length + entry.images.length}</span>
                  </div>
                  <span className="text-xs">{entry.createdBy}</span>
                </div>
                <Button asChild size="sm" className="gradient-button h-8 px-3 text-sm">
                  <Link href={`/knowledge/${entry.id}`}>
                    查看
                    <ChevronRight className="ml-1 h-3.5 w-3.5" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
