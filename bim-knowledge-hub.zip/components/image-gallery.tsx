"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ZoomIn, Download, Maximize2, X } from "lucide-react"
import type { FileAttachment } from "@/lib/types"
import Image from "next/image"

interface ImageGalleryProps {
  images: FileAttachment[]
}

export function ImageGallery({ images }: ImageGalleryProps) {
  const [selectedImage, setSelectedImage] = useState<FileAttachment | null>(null)

  const standardImages = images.filter((_, i) => i % 2 === 0)
  const onsiteImages = images.filter((_, i) => i % 2 === 1)

  if (images.length === 0) {
    return (
      <Card className="p-8 text-center">
        <p className="text-muted-foreground">暂无图片</p>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">全部图片</TabsTrigger>
          <TabsTrigger value="standard">标准示例</TabsTrigger>
          <TabsTrigger value="onsite">现场对比</TabsTrigger>
          <TabsTrigger value="compare">对照查看</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          <div className="grid md:grid-cols-2 gap-4">
            {images.map((image) => (
              <ImageCard key={image.id} image={image} onView={() => setSelectedImage(image)} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="standard" className="mt-4">
          <div className="grid md:grid-cols-2 gap-4">
            {standardImages.map((image) => (
              <ImageCard key={image.id} image={image} onView={() => setSelectedImage(image)} badge="标准" />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="onsite" className="mt-4">
          <div className="grid md:grid-cols-2 gap-4">
            {onsiteImages.map((image) => (
              <ImageCard key={image.id} image={image} onView={() => setSelectedImage(image)} badge="现场" />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="compare" className="mt-4">
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground text-center mb-4">
              左右对比标准做法与现场实际，便于质量检查和培训
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              {standardImages.slice(0, 2).map((stdImage, index) => (
                <div key={index} className="contents">
                  <div className="space-y-2">
                    <Badge variant="default" className="mb-2">
                      标准示例
                    </Badge>
                    <ImageCard image={stdImage} onView={() => setSelectedImage(stdImage)} compact />
                  </div>
                  {onsiteImages[index] && (
                    <div className="space-y-2">
                      <Badge variant="secondary" className="mb-2">
                        现场实际
                      </Badge>
                      <ImageCard
                        image={onsiteImages[index]}
                        onView={() => setSelectedImage(onsiteImages[index])}
                        compact
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {selectedImage && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 right-4 text-white hover:bg-white/20"
            onClick={() => setSelectedImage(null)}
          >
            <X className="h-6 w-6" />
          </Button>
          <div className="relative max-w-5xl w-full h-full flex items-center justify-center">
            <Image
              src={selectedImage.url || "/placeholder.svg"}
              alt={selectedImage.name}
              fill
              className="object-contain"
            />
          </div>
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-background/90 backdrop-blur px-4 py-2 rounded-lg">
            <p className="text-sm font-medium">{selectedImage.name}</p>
          </div>
        </div>
      )}
    </div>
  )
}

function ImageCard({
  image,
  onView,
  badge,
  compact = false,
}: {
  image: FileAttachment
  onView: () => void
  badge?: string
  compact?: boolean
}) {
  return (
    <Card className="overflow-hidden group">
      <div className={`relative ${compact ? "aspect-video" : "aspect-video"} bg-muted`}>
        <Image src={image.url || "/placeholder.svg"} alt={image.name} fill className="object-cover" />
        {badge && (
          <Badge variant={badge === "标准" ? "default" : "secondary"} className="absolute top-2 left-2">
            {badge}
          </Badge>
        )}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
          <Button size="icon" variant="secondary" onClick={onView}>
            <ZoomIn className="h-5 w-5" />
          </Button>
          <Button size="icon" variant="secondary">
            <Maximize2 className="h-5 w-5" />
          </Button>
          <Button size="icon" variant="secondary">
            <Download className="h-5 w-5" />
          </Button>
        </div>
      </div>
      {!compact && (
        <div className="p-3 border-t border-border">
          <p className="text-sm font-medium truncate">{image.name}</p>
          <p className="text-xs text-muted-foreground">
            {(image.size / 1024).toFixed(0)} KB · {image.uploadedAt.toLocaleDateString("zh-CN")}
          </p>
        </div>
      )}
    </Card>
  )
}
