"use client"

import { useState, useCallback, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search, X, Sparkles, Eye, Layers, ChevronRight } from "lucide-react"
import { mockKnowledgeEntries, professionalLabels, riskLevelLabels } from "@/lib/mock-data"
import Link from "next/link"
import { useDebounce } from "@/hooks/use-debounce"

export function HomeAISearch() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<typeof mockKnowledgeEntries>([])
  const [loading, setLoading] = useState(false)
  const debouncedQuery = useDebounce(query, 300)

  const handleSearch = useCallback(async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([])
      return
    }

    setLoading(true)
    try {
      // 模拟搜索延迟
      await new Promise((resolve) => setTimeout(resolve, 200))

      const filtered = mockKnowledgeEntries
        .filter(
          (e) =>
            e.title.includes(searchQuery) ||
            e.description.includes(searchQuery) ||
            e.tags.some((t) => t.includes(searchQuery)),
        )
        .slice(0, 4)
      setResults(filtered)
    } catch (error) {
      console.error("[v0] Search error:", error)
      setResults([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (debouncedQuery) {
      handleSearch(debouncedQuery)
    } else {
      setResults([])
    }
  }, [debouncedQuery, handleSearch])

  const clearSearch = () => {
    setQuery("")
    setResults([])
  }

  return (
    <Card className="glass-card border-2 border-primary/30 overflow-hidden">
      <CardContent className="p-6 md:p-8">
        <div className="grid lg:grid-cols-2 gap-6 lg:gap-8">
          {/* Left: Search Input */}
          <div className="space-y-5">
            <div className="space-y-3">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="h-5 w-5 text-primary icon-glow-primary" />
                <h3 className="text-xl font-bold gradient-text-animated">AI智能搜索</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                输入关键词或自然语言描述，快速找到相关构造做法
              </p>
            </div>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="搜索构造做法、构件信息..."
                className="pl-10 pr-10 h-12 text-base border-primary/30 focus-visible:ring-primary/50"
              />
              {query && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={clearSearch}
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 hover:bg-transparent"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="space-y-3">
              <p className="text-xs text-muted-foreground font-medium">热门搜索</p>
              <div className="flex flex-wrap gap-2">
                {["混凝土楼板", "剪力墙钢筋", "外墙保温", "防水做法"].map((tag) => (
                  <Badge
                    key={tag}
                    variant="outline"
                    className="cursor-pointer hover:bg-primary/10 hover:border-primary/50 transition-all px-3 py-1.5"
                    onClick={() => setQuery(tag)}
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Search Results */}
          <div className="space-y-4">
            {loading && (
              <div className="flex items-center justify-center h-full min-h-[200px]">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
              </div>
            )}

            {!loading && results.length === 0 && query && (
              <div className="flex flex-col items-center justify-center h-full min-h-[200px] text-center space-y-2">
                <Search className="h-12 w-12 text-muted-foreground/50" />
                <p className="text-sm text-muted-foreground">未找到相关结果</p>
              </div>
            )}

            {!loading && results.length === 0 && !query && (
              <div className="flex flex-col items-center justify-center h-full min-h-[200px] text-center space-y-2">
                <Sparkles className="h-12 w-12 text-primary/50 animate-pulse" />
                <p className="text-sm text-muted-foreground">开始输入以搜索构造做法</p>
              </div>
            )}

            {!loading && results.length > 0 && (
              <div className="space-y-3">
                <p className="text-xs text-muted-foreground font-medium">搜索结果 ({results.length})</p>
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                  {results.map((entry, index) => (
                    <Card
                      key={entry.id}
                      className="glass-card hover:shadow-lg transition-all duration-300 group"
                      style={{
                        animation: `fadeIn 240ms ease-out ${index * 40}ms both`,
                      }}
                    >
                      <CardContent className="p-4 space-y-2.5">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <Badge variant="outline" className="text-xs px-2 py-0.5">
                              {professionalLabels[entry.professional]}
                            </Badge>
                            {entry.rvtModel && (
                              <Badge variant="secondary" className="text-xs px-2 py-0.5">
                                <Layers className="h-3 w-3 mr-1" />
                                3D
                              </Badge>
                            )}
                          </div>
                          <Badge
                            variant={
                              entry.riskLevel === "high-risk"
                                ? "destructive"
                                : entry.riskLevel === "important"
                                  ? "default"
                                  : "secondary"
                            }
                            className="text-xs px-2 py-0.5"
                          >
                            {riskLevelLabels[entry.riskLevel]}
                          </Badge>
                        </div>

                        <h4 className="font-semibold text-sm line-clamp-1 group-hover:text-primary transition-colors">
                          {entry.title}
                        </h4>

                        <div className="flex items-center justify-between pt-2 border-t border-border/40">
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Eye className="h-3 w-3" />
                            <span>{entry.views}</span>
                          </div>
                          <Button
                            variant="default"
                            size="sm"
                            asChild
                            className="h-8 text-xs px-4 bg-primary hover:bg-primary/90 text-primary-foreground font-medium shadow-sm"
                          >
                            <Link href={`/knowledge/${entry.id}`} className="flex items-center gap-1">
                              查看详情
                              <ChevronRight className="h-3.5 w-3.5" />
                            </Link>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <Button
                  variant="outline"
                  asChild
                  className="w-full border-primary/30 hover:bg-primary/5 bg-transparent"
                >
                  <Link href="/search/ai">
                    查看所有结果
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
