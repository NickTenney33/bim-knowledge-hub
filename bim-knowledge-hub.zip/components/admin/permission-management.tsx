"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const permissions = [
  { module: "知识库", actions: ["查看", "创建", "编辑", "删除"] },
  { module: "内容管理", actions: ["查看", "创建", "编辑", "删除", "审核", "发布"] },
  { module: "搜索", actions: ["使用搜索", "使用AI助手"] },
  { module: "用户管理", actions: ["查看用户", "添加用户", "编辑用户", "删除用户"] },
  { module: "组织管理", actions: ["查看组织", "编辑组织"] },
  { module: "系统设置", actions: ["查看设置", "修改设置"] },
]

const roles = [
  { id: "viewer", name: "查看者", description: "只能查看内容" },
  { id: "editor", name: "编辑者", description: "可以创建和编辑内容" },
  { id: "reviewer", name: "审核者", description: "可以审核和发布内容" },
  { id: "admin", name: "管理员", description: "拥有所有权限" },
]

export function PermissionManagement() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>角色列表</CardTitle>
          <CardDescription>系统内置的角色和权限配置</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {roles.map((role) => (
            <Card key={role.id} className="border-2">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{role.name}</h3>
                      <Badge variant="outline">{role.id}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{role.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>权限矩阵</CardTitle>
          <CardDescription>不同角色在各模块的权限配置</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>模块</TableHead>
                <TableHead>查看者</TableHead>
                <TableHead>编辑者</TableHead>
                <TableHead>审核者</TableHead>
                <TableHead>管理员</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {permissions.map((perm) => (
                <TableRow key={perm.module}>
                  <TableCell className="font-medium">{perm.module}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-xs">
                      {perm.module === "知识库" || perm.module === "搜索" ? "查看" : "无"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="text-xs">
                      {perm.module === "知识库" || perm.module === "内容管理" ? "编辑" : "查看"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="default" className="text-xs">
                      {perm.module === "内容管理" ? "审核发布" : "查看编辑"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="default" className="text-xs">
                      全部权限
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>访问范围设置</CardTitle>
          <CardDescription>配置不同角色可以访问的内容范围</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <Label className="text-base font-semibold">查看者</Label>
            <div className="space-y-2 ml-4">
              <div className="flex items-center space-x-2">
                <Checkbox id="viewer-own" defaultChecked />
                <label htmlFor="viewer-own" className="text-sm">
                  本人创建的内容
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="viewer-dept" defaultChecked />
                <label htmlFor="viewer-dept" className="text-sm">
                  本部门的内容
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="viewer-company" defaultChecked />
                <label htmlFor="viewer-company" className="text-sm">
                  全公司公开内容
                </label>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <Label className="text-base font-semibold">编辑者</Label>
            <div className="space-y-2 ml-4">
              <div className="flex items-center space-x-2">
                <Checkbox id="editor-own" defaultChecked />
                <label htmlFor="editor-own" className="text-sm">
                  本人创建的内容（编辑）
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="editor-dept" defaultChecked />
                <label htmlFor="editor-dept" className="text-sm">
                  本部门的内容（查看/编辑）
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="editor-company" defaultChecked />
                <label htmlFor="editor-company" className="text-sm">
                  全公司公开内容（查看）
                </label>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
