"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, Eye } from "lucide-react"

export function AnalyticsDashboard() {
  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>总浏览量</CardDescription>
            <CardTitle className="text-3xl">8,524</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="h-4 w-4 mr-1 text-green-500" />
              <span className="text-green-500 font-medium">+12.5%</span>
              <span className="ml-1">vs 上月</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>活跃用户</CardDescription>
            <CardTitle className="text-3xl">1,245</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="h-4 w-4 mr-1 text-green-500" />
              <span className="text-green-500 font-medium">+8.2%</span>
              <span className="ml-1">vs 上月</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>新增内容</CardDescription>
            <CardTitle className="text-3xl">42</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="h-4 w-4 mr-1 text-green-500" />
              <span className="text-green-500 font-medium">+15.8%</span>
              <span className="ml-1">vs 上月</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>热门内容</CardTitle>
          <CardDescription>最受欢迎的知识条目</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { title: "剪力墙钢筋绑扎节点", views: 203, trend: "+12" },
              { title: "机电管线综合排布", views: 178, trend: "+8" },
              { title: "现浇混凝土楼板构造做法", views: 156, trend: "+15" },
              { title: "外墙保温构造做法", views: 92, trend: "+5" },
            ].map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium">{item.title}</p>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Eye className="h-3 w-3" />
                      <span>{item.views} 次浏览</span>
                    </div>
                  </div>
                </div>
                <div className="text-sm text-green-500 font-medium">{item.trend}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>搜索热词</CardTitle>
            <CardDescription>用户最常搜索的关键词</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { keyword: "混凝土楼板", count: 145 },
                { keyword: "剪力墙钢筋", count: 128 },
                { keyword: "机电管线", count: 112 },
                { keyword: "外墙保温", count: 89 },
                { keyword: "防水做法", count: 76 },
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm">{item.keyword}</span>
                  <span className="text-sm text-muted-foreground">{item.count} 次</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>使用时段分析</CardTitle>
            <CardDescription>用户活跃时间分布</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { time: "09:00 - 12:00", usage: "高峰期", percent: 85 },
                { time: "14:00 - 17:00", usage: "高峰期", percent: 78 },
                { time: "12:00 - 14:00", usage: "平缓期", percent: 45 },
                { time: "17:00 - 21:00", usage: "平缓期", percent: 32 },
              ].map((item, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>{item.time}</span>
                    <span className="text-muted-foreground">{item.usage}</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all"
                      style={{ width: `${item.percent}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
