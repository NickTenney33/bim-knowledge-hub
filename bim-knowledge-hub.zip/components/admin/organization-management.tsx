"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Building2, ChevronRight, Users, Plus } from "lucide-react"

const mockOrganization = [
  {
    id: "1",
    name: "技术管理部",
    users: 8,
    children: [
      { id: "1-1", name: "BIM中心", users: 5 },
      { id: "1-2", name: "技术质量组", users: 3 },
    ],
  },
  {
    id: "2",
    name: "设计部",
    users: 35,
    children: [
      { id: "2-1", name: "建筑专业", users: 12 },
      { id: "2-2", name: "结构专业", users: 10 },
      { id: "2-3", name: "机电专业", users: 8 },
      { id: "2-4", name: "装饰专业", users: 5 },
    ],
  },
  {
    id: "3",
    name: "工程部",
    users: 45,
    children: [
      { id: "3-1", name: "项目一部", users: 15 },
      { id: "3-2", name: "项目二部", users: 12 },
      { id: "3-3", name: "项目三部", users: 18 },
    ],
  },
  {
    id: "4",
    name: "质量安全部",
    users: 12,
    children: [],
  },
]

export function OrganizationManagement() {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>组织架构</CardTitle>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              添加部门
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          {mockOrganization.map((dept) => (
            <div key={dept.id} className="space-y-2">
              <Card className="border-2">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                        <Building2 className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{dept.name}</h3>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Users className="h-3 w-3" />
                          <span>{dept.users} 人</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {dept.children.length > 0 && <Badge variant="outline">{dept.children.length} 个子部门</Badge>}
                      <Button variant="ghost" size="icon">
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {dept.children.length > 0 && (
                <div className="ml-8 space-y-2">
                  {dept.children.map((child) => (
                    <Card key={child.id}>
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Building2 className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{child.name}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Users className="h-3 w-3" />
                            <span>{child.users} 人</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
