"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Search, Plus, MoreVertical, Edit, Trash2, Shield } from "lucide-react"

const mockUsers = [
  { id: "1", name: "张工", email: "zhang@company.com", department: "结构部", role: "editor", status: "active" },
  { id: "2", name: "李工", email: "li@company.com", department: "建筑部", role: "editor", status: "active" },
  { id: "3", name: "王工", email: "wang@company.com", department: "机电部", role: "editor", status: "active" },
  { id: "4", name: "赵工", email: "zhao@company.com", department: "装饰部", role: "viewer", status: "active" },
  { id: "5", name: "陈经理", email: "chen@company.com", department: "技术管理部", role: "admin", status: "active" },
]

const roleLabels: Record<string, string> = {
  viewer: "查看者",
  editor: "编辑者",
  reviewer: "审核者",
  admin: "管理员",
}

export function UserManagement() {
  return (
    <Card>
      <CardHeader className="px-5 md:px-6 py-5">
        <div className="flex items-center justify-between">
          <CardTitle>用户列表</CardTitle>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="搜索用户..." className="pl-8 w-64" />
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              添加用户
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="px-5 md:px-6">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>用户</TableHead>
              <TableHead>邮箱</TableHead>
              <TableHead>部门</TableHead>
              <TableHead>角色</TableHead>
              <TableHead>状态</TableHead>
              <TableHead className="text-right">操作</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockUsers.map((user) => (
              <TableRow key={user.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarFallback>{user.name.substring(0, 2)}</AvatarFallback>
                    </Avatar>
                    <span className="font-medium">{user.name}</span>
                  </div>
                </TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>{user.department}</TableCell>
                <TableCell>
                  <Badge variant={user.role === "admin" ? "default" : "secondary"}>{roleLabels[user.role]}</Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{user.status === "active" ? "活跃" : "禁用"}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Edit className="mr-2 h-4 w-4" />
                        编辑
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Shield className="mr-2 h-4 w-4" />
                        修改权限
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        删除
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
