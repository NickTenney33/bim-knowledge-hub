"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { professionalLabels, componentTypeLabels, workProcessLabels, riskLevelLabels } from "@/lib/mock-data"
import { FilterX } from "lucide-react"

export function KnowledgeFilters() {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="px-5 py-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base font-semibold">筛选条件</CardTitle>
            <Button variant="ghost" size="sm" className="h-8 text-sm -mr-1">
              <FilterX className="h-4 w-4 mr-1.5" />
              清除
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-5 px-5 py-4 pt-0">
          {/* Professional Filter */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">专业</Label>
            <div className="space-y-2.5 pl-0.5">
              {Object.entries(professionalLabels).map(([key, label]) => (
                <div key={key} className="flex items-center space-x-3">
                  <Checkbox id={`prof-${key}`} className="h-4 w-4" />
                  <label
                    htmlFor={`prof-${key}`}
                    className="text-sm leading-none cursor-pointer hover:text-foreground/80 transition-colors"
                  >
                    {label}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t" />

          {/* Component Type Filter */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">构造部位</Label>
            <div className="space-y-2.5 pl-0.5">
              {Object.entries(componentTypeLabels).map(([key, label]) => (
                <div key={key} className="flex items-center space-x-3">
                  <Checkbox id={`comp-${key}`} className="h-4 w-4" />
                  <label
                    htmlFor={`comp-${key}`}
                    className="text-sm leading-none cursor-pointer hover:text-foreground/80 transition-colors"
                  >
                    {label}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t" />

          {/* Work Process Filter */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">工序</Label>
            <div className="space-y-2.5 pl-0.5">
              {Object.entries(workProcessLabels).map(([key, label]) => (
                <div key={key} className="flex items-center space-x-3">
                  <Checkbox id={`work-${key}`} className="h-4 w-4" />
                  <label
                    htmlFor={`work-${key}`}
                    className="text-sm leading-none cursor-pointer hover:text-foreground/80 transition-colors"
                  >
                    {label}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t" />

          {/* Risk Level Filter */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">风险等级</Label>
            <RadioGroup defaultValue="all" className="space-y-2.5 pl-0.5">
              <div className="flex items-center space-x-3">
                <RadioGroupItem value="all" id="risk-all" className="h-4 w-4" />
                <label
                  htmlFor="risk-all"
                  className="text-sm leading-none cursor-pointer hover:text-foreground/80 transition-colors"
                >
                  全部
                </label>
              </div>
              {Object.entries(riskLevelLabels).map(([key, label]) => (
                <div key={key} className="flex items-center space-x-3">
                  <RadioGroupItem value={key} id={`risk-${key}`} className="h-4 w-4" />
                  <label
                    htmlFor={`risk-${key}`}
                    className="text-sm leading-none cursor-pointer hover:text-foreground/80 transition-colors"
                  >
                    {label}
                  </label>
                </div>
              ))}
            </RadioGroup>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
