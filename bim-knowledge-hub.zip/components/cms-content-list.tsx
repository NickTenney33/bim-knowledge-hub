"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Eye, Edit, MoreVertical, Trash2, Copy, Archive, Send } from "lucide-react"
import Link from "next/link"
import type { KnowledgeEntry } from "@/lib/types"
import { professionalLabels, riskLevelLabels } from "@/lib/mock-data"

interface CMSContentListProps {
  entries: KnowledgeEntry[]
}

export function CMSContentList({ entries }: CMSContentListProps) {
  if (entries.length === 0) {
    return (
      <Card className="p-12 text-center">
        <p className="text-muted-foreground">暂无内容</p>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {entries.map((entry) => (
        <Card key={entry.id} className="hover:shadow-md transition-shadow">
          <div className="p-5 md:p-6">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2.5 mb-3">
                  <Badge variant="outline">{professionalLabels[entry.professional]}</Badge>
                  <Badge
                    variant={
                      entry.status === "published" ? "default" : entry.status === "review" ? "secondary" : "outline"
                    }
                  >
                    {entry.status === "published" ? "已发布" : entry.status === "review" ? "待审核" : "草稿"}
                  </Badge>
                  <Badge
                    variant={
                      entry.riskLevel === "high-risk"
                        ? "destructive"
                        : entry.riskLevel === "important"
                          ? "default"
                          : "secondary"
                    }
                  >
                    {riskLevelLabels[entry.riskLevel]}
                  </Badge>
                </div>

                <h3 className="text-lg font-semibold mb-2 line-clamp-1 text-balance">{entry.title}</h3>

                <p className="text-sm text-muted-foreground mb-4 line-clamp-2 text-pretty">{entry.description}</p>

                <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                  <span>创建者: {entry.createdBy}</span>
                  <span>·</span>
                  <span>更新于 {entry.updatedAt.toLocaleDateString("zh-CN")}</span>
                  <span>·</span>
                  <span>v{entry.version}</span>
                  <span>·</span>
                  <div className="flex items-center gap-1">
                    <Eye className="h-3 w-3" />
                    <span>{entry.views}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <Button variant="ghost" size="sm" asChild>
                  <Link href={`/knowledge/${entry.id}`}>
                    <Eye className="h-4 w-4 mr-1.5" />
                    预览
                  </Link>
                </Button>

                <Button variant="outline" size="sm" asChild>
                  <Link href={`/cms/edit/${entry.id}`}>
                    <Edit className="h-4 w-4 mr-1.5" />
                    编辑
                  </Link>
                </Button>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <Copy className="mr-2 h-4 w-4" />
                      复制
                    </DropdownMenuItem>
                    {entry.status === "draft" && (
                      <DropdownMenuItem>
                        <Send className="mr-2 h-4 w-4" />
                        提交审核
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem>
                      <Archive className="mr-2 h-4 w-4" />
                      归档
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-destructive">
                      <Trash2 className="mr-2 h-4 w-4" />
                      删除
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
