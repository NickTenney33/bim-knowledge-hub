export interface KnowledgeNode {
  id: string
  title: string
  snippet: string
  tags: string[]
  category: string
  riskLevel?: string
  thumbnailUrl?: string
  relevance: number
}

export interface SearchSuggestion {
  query: string
  category: string
  count: number
}

export interface AISearchResponse {
  nodes: KnowledgeNode[]
  suggestions: SearchSuggestion[]
  totalResults: number
}

const EVOLINK_API_URL = "https://api.evolink.ai/v1/chat/completions"

export class EvolinkService {
  private apiKey: string

  constructor(apiKey?: string) {
    this.apiKey = apiKey || process.env.EVOLINK_API_KEY || ""
  }

  async fetchAI(query: string, context?: string): Promise<AISearchResponse> {
    if (!this.apiKey) {
      throw new Error("EVOLINK_API_KEY not configured")
    }

    try {
      const systemPrompt = `你是BIM知识库的智能搜索助手。
根据用户查询，返回最相关的知识库条目。
返回格式必须是纯JSON，不要有任何markdown标记，格式如下：
{
  "nodes": [
    {
      "id": "唯一标识",
      "title": "标题",
      "snippet": "150字以内的摘要",
      "tags": ["标签1", "标签2"],
      "category": "分类",
      "riskLevel": "高风险/重要/一般",
      "relevance": 0.95
    }
  ],
  "suggestions": [
    {"query": "相关搜索1", "category": "分类", "count": 12},
    {"query": "相关搜索2", "category": "分类", "count": 8}
  ],
  "totalResults": 5
}`

      const userPrompt = context
        ? `用户查询: "${query}"\n相关上下文: ${context}\n\n请返回最相关的知识条目和搜索建议。`
        : `用户查询: "${query}"\n\n请返回最相关的知识条目和搜索建议。`

      const response = await fetch(EVOLINK_API_URL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "gpt-4",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          temperature: 0.3,
          max_tokens: 1500,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        console.error("[v0] Evolink API error:", errorData)
        throw new Error(`API request failed: ${response.status}`)
      }

      const data = await response.json()
      const content = data.choices[0]?.message?.content || ""

      // Extract JSON from potential markdown code blocks
      const jsonMatch = content.match(/\{[\s\S]*\}/)
      const jsonContent = jsonMatch ? jsonMatch[0] : content

      const result = JSON.parse(jsonContent) as AISearchResponse
      return result
    } catch (error) {
      console.error("[v0] Evolink fetchAI error:", error)
      throw error
    }
  }

  async getSuggestions(query: string): Promise<string[]> {
    if (!this.apiKey || query.length < 2) {
      return this.getFallbackSuggestions(query)
    }

    try {
      const response = await fetch(EVOLINK_API_URL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "gpt-4",
          messages: [
            {
              role: "system",
              content:
                '你是搜索建议助手。根据用户输入，生成5个相关的BIM知识库搜索建议。直接返回JSON数组格式：["建议1", "建议2", "建议3", "建议4", "建议5"]',
            },
            {
              role: "user",
              content: `用户输入: "${query}"`,
            },
          ],
          temperature: 0.5,
          max_tokens: 200,
        }),
      })

      if (!response.ok) {
        return this.getFallbackSuggestions(query)
      }

      const data = await response.json()
      const content = data.choices[0]?.message?.content || "[]"
      const jsonMatch = content.match(/\[[\s\S]*\]/)
      const jsonContent = jsonMatch ? jsonMatch[0] : content
      const suggestions = JSON.parse(jsonContent) as string[]
      return suggestions.slice(0, 5)
    } catch (error) {
      console.error("[v0] Evolink getSuggestions error:", error)
      return this.getFallbackSuggestions(query)
    }
  }

  private getFallbackSuggestions(query: string): string[] {
    const fallbackMap: Record<string, string[]> = {
      楼板: ["楼板裂缝预防", "楼板配筋要求", "楼板厚度规范", "楼板模板支设", "楼板混凝土浇筑"],
      钢筋: ["钢筋搭接长度", "钢筋锚固长度", "钢筋绑扎要求", "钢筋保护层厚度", "钢筋接头位置"],
      混凝土: ["混凝土养护", "混凝土强度等级", "混凝土配合比", "混凝土裂缝处理", "混凝土浇筑顺序"],
      模板: ["模板支撑系统", "模板拆除时间", "模板工程验收", "爬模施工要点", "铝模板安装"],
      管线: ["管线综合排布", "管线预留预埋", "机电管线安装", "给排水管道", "电气配管要求"],
    }

    const lowerQuery = query.toLowerCase()
    for (const [key, suggestions] of Object.entries(fallbackMap)) {
      if (lowerQuery.includes(key) || key.includes(lowerQuery)) {
        return suggestions
      }
    }

    return ["楼梯模板支设节点", "空调风管节点", "矿棉板与石膏板节点", "装饰装修墙面作法", "机电管线综合排布"]
  }
}

export const evolinkService = new EvolinkService()

export const fetchAI = async (query: string, options?: { limit?: number }) => {
  const response = await evolinkService.fetchAI(query)
  if (options?.limit) {
    return {
      ...response,
      nodes: response.nodes.slice(0, options.limit),
    }
  }
  return response.nodes
}

export const getSuggestions = (query: string) => evolinkService.getSuggestions(query)
