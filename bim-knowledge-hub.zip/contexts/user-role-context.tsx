"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

export type UserRole = "user" | "admin"

interface UserRoleContextType {
  role: UserRole
  setRole: (role: UserRole) => void
  isLoaded: boolean
}

const UserRoleContext = createContext<UserRoleContextType | undefined>(undefined)

export function UserRoleProvider({ children }: { children: React.ReactNode }) {
  const [role, setRoleState] = useState<UserRole>("user")
  const [isLoaded, setIsLoaded] = useState(false)

  // Load role from localStorage on mount
  useEffect(() => {
    try {
      const savedRole = localStorage.getItem("userRole") as UserRole
      if (savedRole === "user" || savedRole === "admin") {
        setRoleState(savedRole)
      }
    } catch (error) {
      console.error("[v0] Failed to load user role from localStorage:", error)
    }
    setIsLoaded(true)
  }, [])

  // Save role to localStorage when it changes
  const setRole = (newRole: UserRole) => {
    setRoleState(newRole)
    try {
      localStorage.setItem("userRole", newRole)
    } catch (error) {
      console.error("[v0] Failed to save user role to localStorage:", error)
    }
  }

  return <UserRoleContext.Provider value={{ role, setRole, isLoaded }}>{children}</UserRoleContext.Provider>
}

export function useUserRole() {
  const context = useContext(UserRoleContext)
  if (context === undefined) {
    throw new Error("useUserRole must be used within a UserRoleProvider")
  }
  return context
}
